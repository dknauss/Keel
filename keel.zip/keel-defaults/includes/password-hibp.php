<?php
/**
 * Have I Been Pwned range lookup, response validation and diagnostics.
 *
 * Only a five-character SHA-1 prefix is sent; suffix comparison stays local.
 * Unknown responses fail open and are reported separately from clean results.
 * A reply is used to answer the request that asked for it and is then gone:
 * nothing about a password, its hash or the reply is written to the database
 * or to a cache.
 * Loaded by security.php; bootstrap.php retains hook registration.
 *
 * @package Keel
 */

defined( 'ABSPATH' ) || exit;
require_once __DIR__ . '/password-hibp-budget.php';

/**
 * Largest HIBP range response this site will accept, in bytes.
 *
 * A padded range response is ~30-50KB; the cap is the guard against a hijacked
 * or proxied endpoint streaming an unbounded body into memory. It is also the
 * truncation boundary — see keel_hibp_body_is_complete().
 *
 * @return int
 */
function keel_hibp_response_limit() {
	return max( 1024, (int) apply_filters( 'keel_hibp_max_response_bytes', 128 * 1024 ) );
}

/**
 * Whether a range body arrived complete rather than cut off at the transport cap.
 *
 * Checked BEFORE trimming: a capped response can end exactly on a CRLF, and
 * trimming first would hide those bytes and make a truncated range look whole.
 * A truncated range is the dangerous case — the missing tail is indistinguishable
 * from "not breached", so a real match silently reads as clean.
 *
 * @param string $body  Raw response body, untrimmed.
 * @param int    $limit Transport cap in bytes.
 * @return bool
 */
function keel_hibp_body_is_complete( $body, $limit ) {
	return strlen( (string) $body ) < (int) $limit;
}

/**
 * Whether a range body is a well-formed HIBP response.
 *
 * Every line is a 35-character hash suffix, a colon, and a count. Anything else
 * — an HTML error page served with a 200, a captive-portal interstitial, a
 * partial line — is treated as unavailable rather than parsed as "no match".
 *
 * @param string $body Trimmed response body.
 * @return bool
 */
function keel_hibp_body_is_valid( $body ) {
	return 1 === preg_match( '/\A[0-9A-F]{35}:[0-9]+(?:\r?\n[0-9A-F]{35}:[0-9]+)*\z/i', (string) $body );
}

/**
 * Whether a validated range body lists the given hash suffix as a real match.
 *
 * `Add-Padding` asks HIBP to pad the response so its size cannot reveal how many
 * real matches it held; padded rows carry a count of 0 and are not matches.
 *
 * @param string $body   Validated range body.
 * @param string $suffix SHA-1 suffix (everything after the 5-character prefix).
 * @return bool
 */
function keel_hibp_range_contains( $body, $suffix ) {
	foreach ( preg_split( '/\r\n|\n/', (string) $body ) as $line ) {
		$parts = array_pad( explode( ':', trim( $line ), 2 ), 2, '0' );

		if ( (int) $parts[1] > 0 && 0 === strcasecmp( $parts[0], $suffix ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Record bounded, scope-shared evidence without storing credential material.
 *
 * @param string $kind Failure reason.
 * @return null
 */
function keel_hibp_unavailable( $kind ) {
	keel_hibp_budget_note( $kind );
	return null;
}

/**
 * Last validated live lookup.
 *
 * @return int|null
 */
function keel_hibp_last_success() {
	return keel_hibp_budget_evidence()['success'];
}

/**
 * Recent sampled unavailability, not a denial counter.
 *
 * @return array{kind:string,first:int,seen:int}|null
 */
function keel_hibp_last_failure() {
	return keel_hibp_budget_evidence()['failure'];
}

/**
 * One definite answer, remembered for the rest of this request and nowhere else.
 *
 * Some requests check the same password twice: the REST users route validates
 * it as an argument and again before the user is saved. The second check reuses
 * the first answer rather than spending allowance on the same question.
 *
 * The answer lives in this PHP process only and the next lookup replaces it. It
 * is tied to the request that asked, so a long-running worker cannot hand it to
 * a later request, and to the scope, so it does not cross networks. Unknown is
 * never remembered: the next check asks again.
 *
 * @param array{table:string,id:int} $scope Canonical database scope.
 * @param string                     $hash  Upper-case SHA-1 of the password being checked.
 * @param bool|null                  $found A definite answer to remember, or null to recall one.
 * @return bool|null The remembered answer when recalling; null otherwise.
 */
function keel_hibp_request_answer( array $scope, $hash, $found = null ) {
	static $held = null;

	$request = isset( $_SERVER['REQUEST_TIME_FLOAT'] ) ? (float) $_SERVER['REQUEST_TIME_FLOAT'] : 0.0;

	if ( null !== $found ) {
		$held = array(
			'request' => $request,
			'scope'   => $scope,
			'hash'    => $hash,
			'found'   => (bool) $found,
		);
		return null;
	}

	return is_array( $held ) && $request === $held['request'] && $scope === $held['scope'] && hash_equals( $held['hash'], $hash ) ? $held['found'] : null;
}

/**
 * Perform a bounded, padded range lookup; compare the suffix only locally.
 *
 * @param string $password   Password to screen.
 * @param bool   $privileged Whether the check is for a privileged account, and
 *                           so may use the allowance kept back for them.
 * @return bool|null Breached, verified clean, or unknown.
 */
function keel_hibp_lookup( $password, $privileged = false ) {
	$scope = keel_hibp_budget_scope();
	if ( ! $scope ) {
		return null;
	}
	$hash  = strtoupper( sha1( $password ) );
	$known = keel_hibp_request_answer( $scope, $hash );
	if ( null !== $known ) {
		return $known;
	}
	$admission = keel_hibp_budget_admit( $scope, true === $privileged );
	if ( isset( $admission['error'] ) ) {
		return keel_hibp_unavailable( $admission['error'] );
	}
	$ticket = $admission['ticket'];
	if ( ! keel_hibp_budget_owned( $ticket ) ) {
		return keel_hibp_unavailable( 'budget_unavailable' );
	}
	$limit    = keel_hibp_response_limit();
	$response = wp_remote_get(
		'https://api.pwnedpasswords.com/range/' . substr( $hash, 0, 5 ),
		array(
			'timeout'             => max( 1, (int) apply_filters( 'keel_hibp_request_timeout', 4 ) ),
			'limit_response_size' => $limit,
			'headers'             => array( 'Add-Padding' => 'true' ),
		)
	);
	$kind     = '';
	$body     = null;
	if ( is_wp_error( $response ) ) {
		$kind = 'unreachable';
	} elseif ( 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
		$kind = 'http_' . (int) wp_remote_retrieve_response_code( $response );
		if ( ! keel_hibp_budget_kind( $kind ) ) {
			$kind = 'unreachable';
		}
	} else {
		$raw = (string) wp_remote_retrieve_body( $response );
		if ( ! keel_hibp_body_is_complete( $raw, $limit ) ) {
			$kind = 'truncated';
		} elseif ( ! keel_hibp_body_is_valid( trim( $raw ) ) ) {
			$kind = 'malformed';
		} else {
			$body = trim( $raw );
		}
	}
	if ( ! keel_hibp_budget_finish( $ticket, null !== $body, $kind ) ) {
		return keel_hibp_unavailable( 'budget_unavailable' );
	}
	if ( null === $body ) {
		return null;
	}
	$found = keel_hibp_range_contains( $body, substr( $hash, 5 ) );
	keel_hibp_request_answer( $scope, $hash, $found );
	return $found;
}

/**
 * Check a password against known breach data.
 *
 * The network lookup can be switched off entirely — with the KEEL_DISABLE_HIBP
 * constant in wp-config.php, or the keel_disable_hibp filter — for air-gapped
 * sites or policies that forbid the outbound request. Screening then falls back
 * to whatever keel_password_is_pwned returns, so a site can substitute a local
 * breach list without the API call.
 *
 * The keel_password_is_pwned filter this function is named for is applied in
 * keel_hibp_password_verdict(), which both entry points share.
 *
 * @param string $password   Plain-text password to screen.
 * @param bool   $privileged Whether the check is for a privileged account.
 * @return bool True when the password appears in a known breach.
 */
function keel_password_is_pwned( $password, $privileged = false ) {
	return true === keel_hibp_password_verdict( $password, $privileged );
}

/**
 * Screen a password and keep "unknown" apart from "clean".
 *
 * The yes-or-no keel_password_is_pwned() folds unknown into false, which is
 * right where a password is being set: refusing it during somebody else's
 * outage would lock people out. The login re-check needs the third answer, because recording an
 * unknown result as "screened" would skip that account for the whole re-screen
 * interval on the strength of a lookup that never happened.
 *
 * The keel_password_is_pwned filter still gets the last word, so a local breach
 * list can still flag a password during an outage. It cannot turn an unknown
 * into a clean result.
 *
 * @param string $password   Plain-text password to screen.
 * @param bool   $privileged Whether the check is for a privileged account, and
 *                           so may use the allowance kept back for them.
 * @return bool|null Breached, clean, or unknown.
 */
function keel_hibp_password_verdict( $password, $privileged = false ) {
	$pwned = false;

	/**
	 * Filter whether to skip the Have I Been Pwned network lookup.
	 *
	 * @param bool   $disabled Whether the lookup is disabled.
	 * @param string $password The password being screened.
	 */
	$disabled = ( defined( 'KEEL_DISABLE_HIBP' ) && KEEL_DISABLE_HIBP )
		|| (bool) apply_filters( 'keel_disable_hibp', false, $password );

	if ( ! $disabled ) {
		$pwned = keel_hibp_lookup( $password, $privileged );

		/*
		 * Unknown is not the same as clean, and it still does not block.
		 *
		 * Refusing a password because a third-party API is down would lock people
		 * out of their own accounts during somebody else's outage, so screening
		 * fails open exactly as before. What changed is that it no longer fails
		 * *silently*: keel_hibp_lookup() has already recorded the failure, and
		 * Site Health reports it. The rest of the policy — length, the blocklist,
		 * the personal-context rules — is untouched by this and still applies.
		 */
	}

	/**
	 * Filter the breach-screening verdict (e.g. to consult a local blocklist).
	 *
	 * @param bool   $pwned    Whether the password appeared in a known breach.
	 * @param string $password The password being screened.
	 */
	$filtered = (bool) apply_filters( 'keel_password_is_pwned', true === $pwned, $password );

	if ( $filtered ) {
		return true;
	}

	return null === $pwned ? null : false;
}
