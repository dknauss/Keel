<?php
/**
 * Content defaults: search privacy, comments, revisions and author discovery.
 *
 * @package Keel
 */

defined( 'ABSPATH' ) || exit;

/**
 * Apply Keel's stored revision limit.
 *
 * @param int      $number Current revision limit.
 * @param \WP_Post $post   Post being revisioned.
 * @return int
 */
function keel_defaults_revision_limit( $number, $post ) {
	unset( $number, $post );

	return (int) keel_defaults_get( 'post_revisions_limit' );
}

/**
 * Replace the author name in feeds while author archives are disabled.
 *
 * `the_author` is what RSS puts in `<dc:creator>` and Atom in `<author><name>`,
 * so a feed lists the display name of every post's author whether or not the
 * author pages exist. Redirecting `/author/x/` closes the page and leaves the
 * list; this closes the list.
 *
 * Only in feeds. Bylines on the site itself are editorial, and a plugin that
 * silently renamed them everywhere would be doing something nobody asked for.
 *
 * @param string $author Display name.
 * @return string
 */
function keel_defaults_mask_feed_author( $author ) {
	if ( ! is_feed() ) {
		return $author;
	}

	return (string) apply_filters( 'keel_feed_author_name', __( 'Site Contributor', 'keel-defaults' ) );
}

/**
 * Comment types that keep working while comments are disabled.
 *
 * WordPress 6.9's Notes feature stores editorial notes as comments of type
 * `note`. They are not public commentary and have nothing to do with the
 * comment form, so switching comments off must not take them with it.
 *
 * Deliberately does NOT include `comment`: see keel_defaults_empty_comment_queries().
 *
 * @return string[]
 */
function keel_defaults_allowed_comment_types() {
	return array_map( 'strval', (array) apply_filters( 'keel_allowed_comment_types', array( 'note' ) ) );
}

/**
 * Short-circuit comment queries while comments are disabled.
 *
 * `comments_open` and `comments_array` only cover the theme's comment template.
 * Everything else that reads comments — `/wp/v2/comments`, a Recent Comments
 * widget, `wp_count_comments()`, a plugin's own WP_Comment_Query — goes straight
 * to the database and answers normally, so a site with comments "disabled" still
 * serves them to anyone who asks the API. This closes that by answering the
 * query itself.
 *
 * Note where this diverges from Agency Experience implementation it is
 * adapted from. AX lets any query that explicitly asks for type `comment`
 * through, on the reasoning that code deliberately asking for comments should
 * get them. But core's REST controller declares `'type' => array( 'default' =>
 * 'comment' )`, so *every* `GET /wp/v2/comments` arrives asking for exactly that
 * type — the carve-out covers the main exposure it was meant to leave closed.
 * Keel allows only genuinely different comment types (Notes), and lets
 * `comment` be answered as empty, because that is what the toggle says.
 *
 * Nothing is deleted. Turn the default off and every comment is queryable again.
 *
 * @param array|int|null    $comment_data Short-circuit value, null to run the query.
 * @param \WP_Comment_Query $query     The query being run.
 * @return array|int|null
 */
function keel_defaults_empty_comment_queries( $comment_data, $query ) {
	// Without query vars there is no way to tell an allowed type from a
	// disallowed one, so answer empty rather than guess open.
	if ( ! is_object( $query ) || ! isset( $query->query_vars ) || ! is_array( $query->query_vars ) ) {
		return array();
	}

	$allowed = keel_defaults_allowed_comment_types();

	// Both query vars accept a string or an array.
	$requested = array();
	foreach ( array( 'type', 'type__in' ) as $var ) {
		$value = isset( $query->query_vars[ $var ] ) ? $query->query_vars[ $var ] : '';

		if ( '' === $value || null === $value || array() === $value ) {
			continue;
		}

		$requested = array_merge( $requested, array_map( 'strval', (array) $value ) );
	}

	if ( ! empty( $requested ) && ! empty( array_intersect( $requested, $allowed ) ) ) {
		return $comment_data;
	}

	// A count query expects a number, not a list.
	if ( ! empty( $query->query_vars['count'] ) ) {
		return 0;
	}

	return array();
}

/**
 * Hide disallowed comment types from the REST single-item route.
 *
 * The comments_pre_query filter covers WP_Comment_Query, every listing path —
 * but not this one. WP_REST_Comments_Controller::get_comment() calls core's
 * get_comment(), which goes through WP_Comment::get_instance() straight to the
 * row. No query object is built, so the filter that empties comment queries is
 * never consulted, and /wp/v2/comments/123 returned a comment on a site whose
 * comments are switched off.
 *
 * That mattered more than the usual missed hook: "disabling something means it
 * is actually disabled" is the claim this plugin leads with, and this was a
 * documented route where it was not true.
 *
 * Scoped to REST rather than filtering get_comment() globally. The admin,
 * wp_notify_postauthor(), and every other caller still get real comments; only
 * the public API is answered according to the policy. Type-aware for the same
 * reason the query filter is: a site may disable comments while still accepting
 * pingbacks, and those must keep working.
 *
 * @param WP_Comment|null $comment The comment, or null.
 * @return WP_Comment|null
 */
function keel_defaults_hide_rest_comment( $comment ) {
	if ( ! is_object( $comment ) || ! isset( $comment->comment_type ) ) {
		return $comment;
	}

	/*
	 * wp_is_rest_endpoint() (core, 6.5+) covers a served REST request and an
	 * internal rest_do_request() dispatch alike. Keel supports 6.4, which lacks
	 * it, so fall back to the REST_REQUEST constant rest_api_loaded() defines.
	 *
	 * This used to ask a REST-request helper that WordPress does not define,
	 * behind function_exists(), so the guard never fired on any real site.
	 */
	$is_rest = function_exists( 'wp_is_rest_endpoint' )
		? wp_is_rest_endpoint()
		: ( defined( 'REST_REQUEST' ) && REST_REQUEST );

	if ( ! $is_rest ) {
		return $comment;
	}

	$type = '' === (string) $comment->comment_type ? 'comment' : (string) $comment->comment_type;

	if ( in_array( $type, keel_defaults_allowed_comment_types(), true ) ) {
		return $comment;
	}

	// The controller turns an empty comment into its own 404, which is the
	// honest answer: on this site that route has nothing to return.
	return null;
}

/**
 * Refuse a comment submitted while comments are disabled.
 *
 * `comments_open` decides whether core accepts a comment, and it is a filter
 * like any other: a plugin answering it later than Keel wins. Measured
 * 2026-10-24 with a fixture returning `__return_true` at priority 99, the form
 * stayed hidden (Keel's render_block filter) but a POST to
 * wp-comments-post.php was accepted and the comment was stored. Keel reported
 * the divergence and did not prevent it, on a site whose setting says
 * comments are off.
 *
 * `pre_comment_approved` is the last word on every path that creates a
 * comment through core: the form handler, the REST controller, XML-RPC and
 * pingbacks all pass through wp_allow_comment(). Returning a WP_Error there
 * makes each refuse it in its own way (a 403 page, a REST error, a pingback
 * fault). Allowed types such as Notes are let through, as everywhere else.
 *
 * Code that calls wp_insert_comment() directly is not covered and is not meant
 * to be: that is a plugin storing a row on purpose, not a visitor commenting.
 *
 * @param int|string|WP_Error $approved    The approval status so far.
 * @param array               $commentdata The comment being submitted.
 * @return int|string|WP_Error
 */
function keel_defaults_refuse_closed_comment( $approved, $commentdata ) {
	$type = is_array( $commentdata ) && isset( $commentdata['comment_type'] ) ? (string) $commentdata['comment_type'] : '';
	$type = '' === $type ? 'comment' : $type;

	if ( in_array( $type, keel_defaults_allowed_comment_types(), true ) ) {
		return $approved;
	}

	/*
	 * Same code and status core uses for a closed post, so callers that already
	 * handle that refusal handle this one. The two callers read the status in
	 * different shapes: wp-comments-post.php casts the error data to an int,
	 * and the REST server reads data['status'] (a bare 403 there answers 500).
	 */
	$is_rest = function_exists( 'wp_is_rest_endpoint' )
		? wp_is_rest_endpoint()
		: ( defined( 'REST_REQUEST' ) && REST_REQUEST );

	return new WP_Error(
		'comment_closed',
		__( 'Comments are closed on this site.', 'keel-defaults' ),
		$is_rest ? array( 'status' => 403 ) : 403
	);
}

/**
 * Comment blocks removed from the inserter while comments are disabled.
 *
 * @return string[]
 */
function keel_defaults_comment_blocks() {
	return (array) apply_filters(
		'keel_comment_blocks',
		array(
			'core/comment-author-name',
			'core/comment-content',
			'core/comment-date',
			'core/comment-edit-link',
			'core/comment-reply-link',
			'core/comment-template',
			'core/comments',
			'core/comments-pagination',
			'core/comments-pagination-next',
			'core/comments-pagination-numbers',
			'core/comments-pagination-previous',
			'core/comments-title',
			'core/latest-comments',
			'core/post-comments',
			'core/post-comments-form',
		)
	);
}

/**
 * Stop the comment blocks rendering on the front end while comments are disabled.
 *
 * The inserter filter, keel_defaults_remove_comment_blocks(), only decides what
 * an editor can add next. A block theme ships the comment blocks inside its
 * single/post templates already, so on its own that filter leaves every post
 * printing a "Comments" heading above an empty block wrapper — the site reads as
 * broken rather than as one that deliberately has no comments.
 *
 * Returning an empty string rather than unregistering the block types keeps this
 * reversible: the blocks stay registered, the template markup is untouched, and
 * turning the default off brings the whole thing back.
 *
 * @param string $block_content Rendered block markup.
 * @param array  $block         Parsed block, including its blockName.
 * @return string
 */
function keel_defaults_suppress_comment_blocks( $block_content, $block ) {
	if ( ! isset( $block['blockName'] ) ) {
		return $block_content;
	}

	if ( in_array( $block['blockName'], keel_defaults_comment_blocks(), true ) ) {
		return '';
	}

	return $block_content;
}

/**
 * Answer comment feed requests with a 404 while comments are disabled.
 *
 * Removing the <link rel="alternate"> markup only stops the feed being
 * advertised; /comments/feed/ and <post>/feed/ keep answering 200 for anyone who
 * types the URL. Because comment queries are already short-circuited the feed
 * comes back empty, which is arguably worse than either extreme: a live,
 * crawlable endpoint that exists solely to say nothing.
 *
 * Core's set_404() clears the other query flags but deliberately restores
 * is_feed afterwards. Keel clears it explicitly so the template loader stops
 * routing to do_feed() and renders the theme's 404 instead. That ordering is why
 * this runs before the flags are read, and why is_comment_feed() has to be tested
 * first.
 *
 * redirect_canonical() has to go with it. It does not bail on a 404 — it calls
 * redirect_guess_404_permalink() and, on a query this one has just emptied,
 * answers /post-name/feed/ with a 301 to /post-name/feed/feed/. Leaving it in
 * place turns a clean 404 into a redirect to a URL that never existed.
 *
 * @return void
 */
function keel_defaults_block_comment_feeds() {
	if ( ! is_comment_feed() ) {
		return;
	}

	global $wp_query;

	if ( $wp_query instanceof WP_Query ) {
		$wp_query->set_404();
		$wp_query->is_feed = false;
	}

	remove_action( 'template_redirect', 'redirect_canonical' );

	status_header( 404 );
	if ( ! headers_sent() ) {
		header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
	}
	nocache_headers();
}

/**
 * Answer an author-feed request with a real 404 while author archives are off.
 *
 * WordPress marks `/author/{slug}/feed/` as both an author query and a feed.
 * Keel's existing `is_author()` redirect therefore already closed it with the
 * same 301 used for the HTML archive. A feed is not a useful redirect target,
 * though: it is a machine endpoint mirroring a public surface the site disabled.
 * Return 404 explicitly before the archive redirect runs.
 *
 * @return void
 */
function keel_defaults_block_author_feeds() {
	if ( ! is_author() || ! is_feed() ) {
		return;
	}

	global $wp_query;

	if ( $wp_query instanceof WP_Query ) {
		$wp_query->set_404();
		// WP_Query::set_404() preserves the feed flag; the 404 template needs it off.
		$wp_query->is_feed = false;
		keel_defaults_forget_queried_author( $wp_query );
	}

	remove_action( 'template_redirect', 'redirect_canonical' );

	status_header( 404 );
	if ( ! headers_sent() ) {
		header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
	}
	nocache_headers();
}

/**
 * Answer a disabled author archive with a plain 404.
 *
 * The name is kept from when this redirected to the home page; hooks and
 * checks refer to it. A redirect home for a page that does not exist is a soft
 * 404, so every author request now gets a real one: `/?author=N`,
 * `/author/{slug}/` and `?author_name=`, for real and unknown authors alike.
 * `is_author()` is true only for a real author, so the request's own query
 * variables are read too; otherwise an unknown author would get core's answer
 * and a real one Keel's, which tells them apart.
 *
 * Author feeds are converted to a 404 at priority 9 by
 * keel_defaults_block_author_feeds(), whose `set_404()` call clears the author
 * flag before this callback runs.
 *
 * @return void
 */
function keel_defaults_redirect_author_archive() {
	if ( ! is_author() && ! keel_defaults_is_author_request() ) {
		return;
	}

	global $wp_query;

	if ( $wp_query instanceof WP_Query ) {
		$wp_query->set_404();
		keel_defaults_forget_queried_author( $wp_query );
	}

	// Canonical guessing would otherwise redirect /?author=N to the nicename.
	remove_action( 'template_redirect', 'redirect_canonical' );

	status_header( 404 );
	nocache_headers();
}

/**
 * Answer an author archive with nothing published with a plain 404.
 *
 * Runs while author archives are public. Core gives an unknown `?author=N` a
 * 404 but an author with no published posts an empty archive with a 200, and
 * `?author=N` for that author a redirect to the nicename, so the answer told
 * real accounts from unknown ones. An unknown `/author/{slug}/` gets the same
 * 404 instead of core's list of every post. Feeds and paged URLs are included. An
 * author with published posts keeps core's archive and canonical redirect.
 *
 * @return void
 */
function keel_defaults_404_empty_author_archive() {
	global $wp_query;

	if ( ! is_author() || ! $wp_query instanceof WP_Query ) {
		return;
	}

	// An unknown /author/{slug}/ lists every post instead of no author's.
	if ( $wp_query->have_posts() && get_queried_object() instanceof WP_User ) {
		return;
	}

	$wp_query->set_404();
	// WP_Query::set_404() preserves the feed flag; the 404 template needs it off.
	$wp_query->is_feed = false;
	keel_defaults_forget_queried_author( $wp_query );

	remove_action( 'template_redirect', 'redirect_canonical' );

	status_header( 404 );
	if ( ! headers_sent() ) {
		header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
	}
	nocache_headers();
}

/**
 * Drop the queried author from a query that has just been set to 404.
 *
 * `WP_Query::set_404()` keeps the queried object. Left in place, a real
 * author's ID marks a page with the same ID as current in navigation blocks,
 * so a real author's 404 page would differ from an unknown author's.
 *
 * @param WP_Query $query The main query.
 * @return void
 */
function keel_defaults_forget_queried_author( $query ) {
	$query->queried_object    = null;
	$query->queried_object_id = null;

	// set_404() keeps the found posts too. A theme without 404.php falls back
	// to index.php, whose Loop would still list the author's posts.
	$query->posts         = array();
	$query->post          = null;
	$query->post_count    = 0;
	$query->found_posts   = 0;
	$query->max_num_pages = 0;
	$query->current_post  = -1;
	$GLOBALS['post']      = null; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
}

/**
 * Whether the main request asked for an author archive, existing or not.
 *
 * Reads the parsed query variables (`?author=N`, `/author/{slug}/`). Feeds are
 * left out: keel_defaults_block_author_feeds() answers them.
 *
 * @return bool
 */
function keel_defaults_is_author_request() {
	global $wp;

	if ( ! $wp instanceof WP || ! is_array( $wp->query_vars ) || ! empty( $wp->query_vars['feed'] ) ) {
		return false;
	}

	foreach ( array( 'author', 'author_name' ) as $var ) {
		if ( isset( $wp->query_vars[ $var ] ) && ( ! is_scalar( $wp->query_vars[ $var ] ) || '' !== (string) $wp->query_vars[ $var ] ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Record whether the rewrite rules being generated include the random block.
 *
 * Core builds the `/random/` rules only when rewrite rules are generated, and
 * saves them. Whether they belong there can change afterwards: this site's
 * setting, a network policy that sets or lifts it, a configuration constant,
 * another plugin answering the same filter, or a database restored from
 * elsewhere. Remembering what the saved rules were built under lets
 * keel_defaults_check_random_rules() notice every one of those on the next
 * request, on each site of a network, without watching any of them.
 *
 * Runs on `rewrite_rules_array`, which fires only while rules are generated.
 * The option is written only when the answer changes.
 *
 * @param mixed $rules Generated rewrite rules, returned unchanged.
 * @return mixed
 */
function keel_defaults_note_random_rules( $rules ) {
	$state = wp_is_random_content_redirect_enabled() ? 'on' : 'off';

	if ( get_option( 'keel_random_rules_state' ) !== $state ) {
		update_option( 'keel_random_rules_state', $state, true );
	}

	return $rules;
}

/**
 * Rebuild the saved rewrite rules when they disagree with the random setting.
 *
 * Saved while the redirects were on and kept after they were turned off, the
 * rules still match `/random/`; core then ignores the `random` variable they
 * set and renders the blog home with a 200. Saved while the redirects were off
 * and kept after they were turned back on, `/random/` is a 404. Deleting the
 * saved rules is WordPress's own soft flush: the request that parses the URL
 * rebuilds them, so this request already gets the right answer.
 *
 * Runs late on `init`, after every plugin has answered the filter. A site
 * without saved rules (plain permalinks) has nothing to rebuild, which also
 * keeps it from deleting an empty option on every request.
 *
 * @return void
 */
function keel_defaults_check_random_rules() {
	if ( ! get_option( 'rewrite_rules' ) ) {
		return;
	}

	$state = wp_is_random_content_redirect_enabled() ? 'on' : 'off';

	if ( get_option( 'keel_random_rules_state' ) !== $state ) {
		delete_option( 'rewrite_rules' );
	}
}

/**
 * Find no post for a random redirect scoped to an author.
 *
 * With nothing selected, core answers 404 for every author, real or not, so the
 * response no longer says which author slugs or IDs exist.
 *
 * @param \WP_Query $query Query being prepared.
 * @return void
 */
function keel_defaults_block_random_author( $query ) {
	if ( ! $query instanceof WP_Query || ! $query->is_author() || ! function_exists( 'wp_is_random_content_query' ) ) {
		return;
	}

	if ( wp_is_random_content_query( $query ) ) {
		$query->set( 'post__in', array( 0 ) );
	}
}

/**
 * Drop the comment blocks from the editor while comments are disabled.
 *
 * Offering a Comments block on a site with comments off produces a block that
 * renders nothing, which reads as a broken theme rather than a deliberate
 * setting.
 *
 * The two edge cases in the incoming value are the whole difficulty:
 *
 * - `false` means another filter has already disallowed every block. Expanding
 *   it to "all registered blocks minus comments" would re-enable everything that
 *   filter just turned off, so it is returned untouched.
 * - `array()` is also a deny-all — WordPress treats an empty list the same as
 *   `false` — so it must not be expanded either. The loop below returns it
 *   unchanged, which is correct by construction.
 *
 * @param bool|string[] $allowed_block_types Allowed block types, or true/false.
 * @return bool|string[]
 */
function keel_defaults_remove_comment_blocks( $allowed_block_types ) {
	if ( false === $allowed_block_types ) {
		return false;
	}

	// Expand to every registered block only when the value is not already an
	// explicit list (true, or something unexpected).
	if ( ! is_array( $allowed_block_types ) ) {
		if ( ! class_exists( 'WP_Block_Type_Registry' ) ) {
			return $allowed_block_types;
		}

		$allowed_block_types = array_keys( WP_Block_Type_Registry::get_instance()->get_all_registered() );
	}

	$disallowed = keel_defaults_comment_blocks();
	$filtered   = array();

	foreach ( $allowed_block_types as $block ) {
		if ( ! in_array( $block, $disallowed, true ) ) {
			$filtered[] = $block;
		}
	}

	return $filtered;
}

/**
 * Drop the emoji plugin from the TinyMCE plugin list.
 *
 * Core registers `wpemoji` for the classic editor separately from the front-end
 * and admin-head emoji output, so removing those actions leaves this one
 * loading. Anything that is not an array is replaced rather than filtered: the
 * filter contract is a list, and a plugin returning something else has already
 * broken it.
 *
 * @param mixed $plugins TinyMCE plugin list.
 * @return array
 */
function keel_defaults_remove_emoji_tinymce_plugin( $plugins ) {
	return is_array( $plugins ) ? array_values( array_diff( $plugins, array( 'wpemoji' ) ) ) : array();
}

/**
 * Remove author identity from oEmbed responses.
 *
 * `oembed/1.0/embed` returns `author_name` and `author_url` for every post, and
 * the URL carries the account's nicename. Redirecting `/author/` archives does
 * nothing about it, so a site that had hidden its authors was still handing out
 * login names through a route nobody thinks of as a user endpoint.
 *
 * Measured on a live install before the fix: with `disable_author_archives` on
 * and `/author/admin/` answering 301, oEmbed still returned `admin` and
 * `http://example.test/author/admin/`.
 *
 * The rest of the response — title, provider, and the embed markup — is left
 * alone, so embeds on other sites keep working.
 *
 * @param mixed $data oEmbed response data.
 * @return mixed
 */
function keel_defaults_strip_oembed_author( $data ) {
	if ( ! is_array( $data ) ) {
		return $data;
	}

	unset( $data['author_name'], $data['author_url'] );

	return $data;
}

/**
 * Drop core's users sitemap when author archives are hidden.
 *
 * `wp-sitemap-users-1.xml` lists every author's archive URL by nicename. With
 * the archives redirected those URLs go nowhere, but the sitemap is still a
 * published list of account names — an enumeration source by construction, and
 * one that search engines are explicitly invited to read.
 *
 * Removing the provider is the whole fix; the rest of the sitemap index is
 * untouched, so posts and pages stay listed.
 *
 * @param mixed  $provider Sitemap provider instance, or false.
 * @param string $name     Provider name.
 * @return mixed
 */
function keel_defaults_drop_users_sitemap( $provider, $name ) {
	return ( 'users' === $name ) ? false : $provider;
}

/**
 * Keep protected search results only when the current visitor has access.
 *
 * Core excludes passwords from anonymous searches, but its read_post capability
 * accepts any published post for a Subscriber. edit_post is the per-object
 * editorial capability; post_password_required also honors cookies and plugin
 * access filters. Never infer access from a role or the post's author ID alone.
 *
 * Inspect only protected rows matching the existing joins/where/grouping, before
 * LIMIT. Adding the allowlist to SQL keeps counts, pagination and ID-only queries
 * correct, and makes WordPress's query-cache key reflect the visible result set.
 * The extra read is limited to logged-in searches, not ordinary page requests.
 *
 * @param array     $clauses WordPress query clauses.
 * @param \WP_Query $query   Current query, including secondary search queries.
 * @return array
 */
function keel_defaults_protect_search( $clauses, $query ) {
	if ( ! $query->is_search() || $query->is_admin ) {
		return $clauses;
	}

	global $wpdb;

	$allowed = array();
	if ( is_user_logged_in() ) {
		// These are WordPress's already-built clauses, not request parameters.
		$sql = "SELECT DISTINCT {$wpdb->posts}.* FROM {$wpdb->posts} {$clauses['join']} WHERE 1=1 {$clauses['where']} AND {$wpdb->posts}.post_password <> ''";
		if ( '' !== $clauses['groupby'] ) {
			$sql .= ' GROUP BY ' . $clauses['groupby'];
		}

		// No persistent allowlist: capability/password filters can change within a request.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared -- trusted WP_Query clauses; dynamic access must be checked before pagination.
		$protected = $wpdb->get_results( $sql );
		if ( is_array( $protected ) ) {
			// Prime in bulk so per-object capability resolution does not fetch each post.
			update_post_cache( $protected );
			foreach ( $protected as $post ) {
				if ( current_user_can( 'edit_post', (int) $post->ID ) || ! post_password_required( $post ) ) {
					$allowed[] = (int) $post->ID;
				}
			}
		}
	}

	$condition = "{$wpdb->posts}.post_password = ''";
	if ( $allowed ) {
		// IDs come from database rows and are cast to integers above.
		$condition .= " OR {$wpdb->posts}.ID IN (" . implode( ',', $allowed ) . ')';
	}
	$clauses['where'] .= ' AND (' . $condition . ')';

	return $clauses;
}
