<?php
/**
 * Translatable display strings for the settings schema.
 *
 * Kept separate from schema.php so the structural schema stays free of __() and
 * safe to build at plugins_loaded. Every function here runs only at render time
 * (settings page, Site Health, Help tab) — all post-init — so translations
 * resolve and no early text-domain load is triggered.
 *
 * @package Keel
 */

defined( 'ABSPATH' ) || exit;

/**
 * Per-setting display copy (label, statement, help, choice/range labels).
 *
 * @return array[]
 */
function keel_defaults_strings() {
	return array(
		'restrict_rest_user_discovery'    => array(
			'label'     => __( 'REST User Discovery', 'keel-defaults' ),
			'statement' => __( 'Hide users from anonymous REST requests', 'keel-defaults' ),
			'help'      => __( 'Stops the REST API from listing usernames to logged-out visitors.', 'keel-defaults' ),
			'detail'    => __( 'Stops the REST API from listing account login names to logged-out visitors. Without it, anyone can read <code>/wp/v2/users</code> and collect valid usernames — half of what a password-guessing attack needs, so the attacker no longer has to find the username first.', 'keel-defaults' ),
		),
		'disable_rest'                    => array(
			'label'     => __( 'REST Authentication', 'keel-defaults' ),
			'statement' => __( 'Require authentication for all REST requests', 'keel-defaults' ),
			'help'      => __( 'Blocks REST requests from logged-out visitors, which can break public blocks, search and integrations.', 'keel-defaults' ),
			'detail'    => __( 'Blocks anonymous REST entirely and stops advertising the endpoint. The logged-in block editor still works, but public blocks, search, and integrations may not. <code>oembed/1.0</code> stays open so other sites can still embed your posts — it serves only what a published post already shows. Filter: <code>keel_public_rest_routes</code>.', 'keel-defaults' ),
		),
		'xmlrpc_allow_pingbacks'          => array(
			'label'     => __( 'XML-RPC Pingbacks', 'keel-defaults' ),
			'statement' => __( 'Accept incoming pingbacks', 'keel-defaults' ),
			'help'      => __( 'Accepts pingbacks sent to this site over XML-RPC.', 'keel-defaults' ),
			'detail'    => __( 'Off by default. Removes <code>pingback.ping</code> — a spam/reflection-DDoS vector — and the <code>X-Pingback</code> header.', 'keel-defaults' ),
		),
		'xmlrpc_allow_remote_publishing'  => array(
			'label'     => __( 'XML-RPC Remote Publishing', 'keel-defaults' ),
			'statement' => __( 'Allow remote publishing (blogging apps)', 'keel-defaults' ),
			'help'      => __( 'Lets apps publish and manage content over XML-RPC with a username and password.', 'keel-defaults' ),
			'detail'    => __( 'Off by default. Removes credential-authenticated <code>wp.*/metaWeblog/MT/blogger</code> methods and the RSD link. Leave it on while Jetpack is active unless connection and feature testing proves it unnecessary.', 'keel-defaults' ),
		),
		'xmlrpc_allow_multicall'          => array(
			'label'     => __( 'XML-RPC Multicall', 'keel-defaults' ),
			'statement' => __( 'Allow <code>system.multicall</code>', 'keel-defaults' ),
			'help'      => __( 'Accepts XML-RPC requests that bundle several calls into one. Jetpack works without it.', 'keel-defaults' ),
			'detail'    => __( 'Leave off when using Jetpack: Keel still allows requests Jetpack verifies as signed by WordPress.com, which uses multicall to manage connected sites. Turning this on allows other multicalls too. If Site Health reports that Jetpack cannot verify these requests, update Jetpack or allow multicall until compatibility is restored. <code>system.multicall</code> bundles several XML-RPC calls into one request. Refusing unsigned multicalls reduces the available attack surface; WordPress has limited its use for password guessing since 4.4.', 'keel-defaults' ),
		),
		'block_xmlrpc_endpoint'           => array(
			'label'     => __( 'XML-RPC Endpoint', 'keel-defaults' ),
			'statement' => __( 'Block the endpoint entirely (returns 403)', 'keel-defaults' ),
			'help'      => __( 'Answers every XML-RPC request with 403. This breaks Jetpack’s connection.', 'keel-defaults' ),
			'detail'    => __( 'Strictest tier — <code>xmlrpc.php</code> answers 403 for every request. Leave XML-RPC reachable while Jetpack is active, unless connection and feature testing proves Jetpack no longer needs it. The XML-RPC help tab explains why this runs inside WordPress and when blocking further out is better.', 'keel-defaults' ),
		),
		'disable_application_passwords'   => array(
			'label'     => __( 'Application Passwords', 'keel-defaults' ),
			'statement' => __( 'Prohibit application passwords', 'keel-defaults' ),
			'help'      => __( 'Stops anyone from creating or using application passwords for API access.', 'keel-defaults' ),
			'detail'    => __( 'Off by default — application passwords are hashed, revocable, per-application credentials for REST and XML-RPC, and usually the safest way to grant API access. They carry the owning account\'s full access and skip interactive 2FA, so prohibit them only when policy requires every login to pass 2FA or SSO, or when no integration needs API access at all.', 'keel-defaults' ),
		),
		'uniform_login_answers'           => array(
			'label'     => __( 'Login Answers', 'keel-defaults' ),
			'statement' => __( 'Answer failed logins and password resets the same whether or not the account exists', 'keel-defaults' ),
			'help'      => __( 'Stops the login and lost-password forms from telling visitors which usernames and email addresses have accounts.', 'keel-defaults' ),
			'detail'    => __( 'WordPress tells visitors whether an account exists: the login form gives an unknown username, an unknown email address and a wrong password three different messages, and the lost-password form answers "Check your email" only for a real account. With this on, every failed sign-in gets one message that repeats nothing typed, and every reset request is sent to "Check your email", whether or not an account exists. Mail still goes only to real accounts, so a mistyped address gets no mail and no error. Covered: the login form at <code>wp-login.php</code> (including the session-expired re-login and forms that post to it) and its lost-password form. Not covered: registration, the profile and user-edit screens, the reset-link screens, response time (a real account still takes longer, because WordPress checks its password, or stores a reset key and sends mail), login attempt limiting, REST requests signed with an application password, XML-RPC, and login forms other plugins render themselves, such as WooCommerce My Account. On multisite, a site’s lost-password link leads to the main site’s form when the site’s address has no path of its own (every site on a subdomain network, and any site with its own domain), so the main site’s setting, or network policy, decides it. A site at a path such as <code>/blog/</code> serves its own form.', 'keel-defaults' ),
		),
		'require_strong_passwords'        => array(
			'label'     => __( 'Password Strength', 'keel-defaults' ),
			'statement' => __( 'Require strong passwords', 'keel-defaults' ),
			'help'      => __( 'Requires 15 or more characters, not the username or email name, not a common password, and not found in a known breach.', 'keel-defaults' ),
			'detail'    => __( '15+ characters, not your username or email name, not a common choice, and not found in a known breach. Every account is breach-screened, including roles listed under Password Policy Exemptions — the exemption covers the other rules only. The Passwords help tab explains why the rules are shaped this way and what the breach check sends.', 'keel-defaults' ),
		),
		'password_exempt_roles'           => array(
			'label'  => __( 'Password Policy Exemptions', 'keel-defaults' ),
			'help'   => __( 'Roles that skip the length, common-password and username rules. Breach screening still applies to everyone.', 'keel-defaults' ),
			'detail' => __( 'Roles that skip the length, common-password and username rules; breach screening still applies to everyone. Only roles with no content or settings capabilities appear — which is why Contributor does not. A user is exempt only if every role they hold is listed in this setting. Filter: <code>keel_weak_roles</code>.', 'keel-defaults' ),
		),
		'protect_public_names'            => array(
			'label'     => __( 'Public Names', 'keel-defaults' ),
			'statement' => __( 'Keep logins and email addresses out of public names', 'keel-defaults' ),
			'help'      => __( 'When an account is saved, a display name, nickname or author slug that repeats the login or email address is replaced with a safe one.', 'keel-defaults' ),
			'detail'    => __( 'Off by default. When an account is saved, a display name, nickname or author slug that repeats the login or email address is replaced with a safe one. Names that are already safe are kept, and logins, email addresses and passwords never change. To fix existing accounts, run the cleanup under Users → Public Names. On multisite networks, the same user account can be active on multiple sites, so network policy or the main site’s setting turns this protection on or off for every site. The cleanup is run from Network Admin, one site at a time.', 'keel-defaults' ),
		),
		'limit_unfiltered_html_to_admins' => array(
			'label'     => __( 'Unfiltered HTML', 'keel-defaults' ),
			'statement' => __( 'Limit raw HTML and JavaScript to Administrators', 'keel-defaults' ),
			'help'      => __( 'Only Administrators can save raw HTML and scripts.', 'keel-defaults' ),
			'detail'    => __( 'Removes the <code>unfiltered_html</code> capability from Editors and every non-Administrator, so only Administrators (and Super Admins on multisite) can save raw, unfiltered HTML and scripts. Cuts stored-XSS risk from lower-privileged editorial accounts. On by default.', 'keel-defaults' ),
		),
		'remove_version'                  => array(
			'label'     => __( 'Version Fingerprint', 'keel-defaults' ),
			'statement' => __( 'Remove the WordPress version fingerprint', 'keel-defaults' ),
			'help'      => __( 'Removes the WordPress version from the page’s generator tag.', 'keel-defaults' ),
			'detail'    => __( 'Strips the generator meta tag. Obscurity, not hardening — it trims scanner noise but does not make an out-of-date site any safer, and the version still leaks from asset query strings and feeds.', 'keel-defaults' ),
		),
		'security_headers'                => array(
			'label'     => __( 'Security Headers', 'keel-defaults' ),
			'statement' => __( 'Send baseline security headers', 'keel-defaults' ),
			'help'      => __( 'Sends the <code>X-Content-Type-Options</code> and <code>Referrer-Policy</code> headers, without replacing ones already set.', 'keel-defaults' ),
			'detail'    => __( '<code>X-Content-Type-Options</code>: <code>nosniff</code> and <code>Referrer-Policy</code>: <code>strict-origin-when-cross-origin</code>. Both are low-risk. Framing is controlled separately, under Frame Options, because that is the one that can break a site. Already-set headers are never overwritten.', 'keel-defaults' ),
		),
		'frame_options'                   => array(
			'label'   => __( 'Frame Options', 'keel-defaults' ),
			'help'    => __( 'Decides whether other sites can show this one in an iframe.', 'keel-defaults' ),
			'detail'  => __( 'Controls who may embed this site in an iframe. <code>SAMEORIGIN</code> permits framing only by this site and can block previews embedded on WordPress.com, partner sites, or other preview tools. Choose Leave unchanged if cross-origin previews or embeds are needed. This stops Keel adding the header; it does not remove a restriction set by your host, CDN, or another plugin. Test the preview after changing this setting.', 'keel-defaults' ),
			'choices' => array(
				'SAMEORIGIN' => __( 'SAMEORIGIN — only this site may frame it', 'keel-defaults' ),
				'DENY'       => __( 'DENY — nobody may frame it', 'keel-defaults' ),
				''           => __( 'Leave unchanged (host/CDN sets it, or the site is embedded elsewhere)', 'keel-defaults' ),
			),
		),
		'disable_ai_connectors'           => array(
			'label'     => __( 'AI Connectors', 'keel-defaults' ),
			'statement' => __( 'Disable AI provider connectors', 'keel-defaults' ),
			'help'      => __( 'Turns off WordPress’s AI provider connectors and the Connectors screen.', 'keel-defaults' ),
			'detail'    => __( 'Turns off WordPress 7.0 AI provider connectors via the <code>wp_supports_ai</code> gate and closes the core Connectors screen. Other plugins that read the same gate, Jetpack among them, switch their own AI features off as well. Also fires <code>keel_disable_ai_connectors</code> for AI integrations core does not know about.', 'keel-defaults' ),
		),
		'core_update_policy'              => array(
			'label'   => __( 'Core Auto-Updates', 'keel-defaults' ),
			'help'    => __( 'Chooses which WordPress releases install automatically.', 'keel-defaults' ),
			'detail'  => __( 'Chooses which core updates install automatically. Minor releases are maintenance and security fixes; major releases are feature updates that can break incompatible themes and plugins. If an explicit <code>wp-config.php</code> policy exists, it takes precedence, and then this control is locked.', 'keel-defaults' ),
			'choices' => array(
				'minor'   => __( 'Maintenance/security releases only — recommended', 'keel-defaults' ),
				'all'     => __( 'All stable releases', 'keel-defaults' ),
				'manual'  => __( 'No automatic core releases', 'keel-defaults' ),
				'inherit' => __( 'Leave unchanged (WordPress, host, or another plugin decides)', 'keel-defaults' ),
			),
		),
		'plugin_auto_update_policy'       => array(
			'label'   => __( 'Plugin Auto-Updates', 'keel-defaults' ),
			'help'    => __( 'Turns automatic plugin updates on or off for every plugin, or leaves each plugin’s own choice.', 'keel-defaults' ),
			'detail'  => __( 'Applies to all eligible code updates, without a minor-only channel. Leave unchanged preserves WordPress’s per-item choices and other filters. Enabled or Disabled overrides those choices at Keel’s filter priority; later filters may still decide differently. Stored per-item choices are never rewritten. On multisite, network policy wins; otherwise the main site’s setting decides for the shared files. Global update restrictions still apply. Review effective decisions on the Updates screen.', 'keel-defaults' ),
			'choices' => array(
				'enabled'  => __( 'Enabled', 'keel-defaults' ),
				'disabled' => __( 'Disabled', 'keel-defaults' ),
				'unset'    => __( 'Leave unchanged (WordPress per-item choices and other filters decide)', 'keel-defaults' ),
			),
		),
		'theme_auto_update_policy'        => array(
			'label'   => __( 'Theme Auto-Updates', 'keel-defaults' ),
			'help'    => __( 'Turns automatic theme updates on or off for every theme, or leaves each theme’s own choice.', 'keel-defaults' ),
			'detail'  => __( 'Applies to all eligible code updates, without a minor-only channel. Leave unchanged preserves WordPress’s per-item choices and other filters. Enabled or Disabled overrides those choices at Keel’s filter priority; later filters may still decide differently. Stored per-item choices are never rewritten. On multisite, network policy wins; otherwise the main site’s setting decides for the shared files. Global update restrictions still apply. Review effective decisions on the Updates screen.', 'keel-defaults' ),
			'choices' => array(
				'enabled'  => __( 'Enabled', 'keel-defaults' ),
				'disabled' => __( 'Disabled', 'keel-defaults' ),
				'unset'    => __( 'Leave unchanged (WordPress per-item choices and other filters decide)', 'keel-defaults' ),
			),
		),
		'auto_update_translations'        => array(
			'label'     => __( 'Translations', 'keel-defaults' ),
			'statement' => __( 'Automatically update translation files', 'keel-defaults' ),
			'help'      => __( 'Installs language updates for WordPress, plugins and themes automatically.', 'keel-defaults' ),
			'detail'    => __( 'Installs available WordPress, plugin, and theme language updates. Plugin and theme code updates use the Plugin Auto-Updates and Theme Auto-Updates policies; Leave unchanged preserves WordPress’s per-item choices.', 'keel-defaults' ),
		),
		'disable_comments'                => array(
			'label'     => __( 'Comments', 'keel-defaults' ),
			'statement' => __( 'Disable comments, trackbacks, and pingbacks', 'keel-defaults' ),
			'help'      => __( 'Closes and hides comments everywhere, without deleting any.', 'keel-defaults' ),
			'detail'    => __( 'Closes comments everywhere, hides existing threads, defaults new content to closed, and reports a count of zero. Removes the admin menu, admin-bar node, Recent Comments dashboard widget, comment feeds, and the comment blocks — both from the inserter and from what a block theme renders. Nothing is deleted: turn this off and every comment comes back.', 'keel-defaults' ),
		),
		'disable_pingbacks'               => array(
			'label'     => __( 'Pingbacks On New Posts', 'keel-defaults' ),
			'statement' => __( 'Close pingbacks and trackbacks on new posts by default', 'keel-defaults' ),
			'help'      => __( 'New posts start with pingbacks and trackbacks closed.', 'keel-defaults' ),
		),
		'disable_self_pingbacks'          => array(
			'label'     => __( 'Self-Pingbacks', 'keel-defaults' ),
			'statement' => __( 'Disable self-pingbacks', 'keel-defaults' ),
			'help'      => __( 'Stops links between your own posts from sending pingbacks.', 'keel-defaults' ),
		),
		'disable_author_archives'         => array(
			'label'     => __( 'Author Archives', 'keel-defaults' ),
			'statement' => __( 'Disable public author archives', 'keel-defaults' ),
			'help'      => __( 'Answers author archive pages with a 404, so they cannot reveal usernames.', 'keel-defaults' ),
			'detail'    => __( 'Returns a 404 for <code>/author/{slug}/</code>, <code>?author=N</code> and their feeds, the same for real and unknown authors. Author pages leak usernames (like the REST users list) and are usually thin, duplicate content.', 'keel-defaults' ),
		),
		'redirect_attachment_pages'       => array(
			'label'     => __( 'Attachment Pages', 'keel-defaults' ),
			'statement' => __( 'Redirect attachment pages to the parent post', 'keel-defaults' ),
			'help'      => __( 'Sends attachment pages to the post they belong to, or to the file.', 'keel-defaults' ),
			'detail'    => __( 'Sends thin attachment pages to the parent post, or to the file itself when the media is unattached. Skipped automatically when the theme provides <code>attachment.php</code> or <code>image.php</code>, since the theme means to render them. Core has its own switch since 6.4 (<code>wp_attachment_pages_enabled</code>); this prefers the parent post over the bare file.', 'keel-defaults' ),
		),
		'disable_random_redirects'        => array(
			'label'     => __( 'Random Post Redirects', 'keel-defaults' ),
			'statement' => __( 'Disable random post redirects', 'keel-defaults' ),
			'help'      => __( 'Turns off the /random/ links WordPress 7.2 adds, which send visitors to a random post.', 'keel-defaults' ),
			'detail'    => __( 'WordPress 7.2 answers <code>/random/</code>, <code>/random/category/{slug}/</code>, <code>/random/author/{slug}/</code>, and <code>?random</code> on any archive with a redirect to a random published post. A site that never asked for them gets new public addresses that a page cache cannot absorb: each redirect is sent uncacheable, and on a site without a persistent object cache some requests still sort posts randomly in the database. Any published post without a password can come up, including one an SEO plugin marks noindex, and so can posts of any public custom post type with an archive. Random author requests are closed by Author Archives, not by this setting: while Author Archives is off they return a 404 either way. This returns false from <code>wp_enable_random_content_redirect</code>, which drops the rewrite rules and hides the Random base field on the Permalinks screen.', 'keel-defaults' ),
		),
		'disable_emojis'                  => array(
			'label'     => __( 'Emoji Script', 'keel-defaults' ),
			'statement' => __( 'Disable the emoji detection script', 'keel-defaults' ),
			'help'      => __( 'Removes the emoji detection script and its styles from every page.', 'keel-defaults' ),
		),
		'disable_post_passwords'          => array(
			'label'     => __( 'Post Passwords', 'keel-defaults' ),
			'statement' => __( 'Hide post password protection in the editor', 'keel-defaults' ),
			'help'      => __( 'Hides the Password protected option in the editor.', 'keel-defaults' ),
			'detail'    => __( 'Hides the "Password protected" visibility option in the editor. WordPress post passwords are weak and are bypassed by full-page caching, which serves the same cached page regardless. Existing password-protected posts keep their field so they stay editable. Off by default.', 'keel-defaults' ),
		),
		'protect_search'                  => array(
			'label'     => __( 'Protected Search Results', 'keel-defaults' ),
			'statement' => __( 'Hide password-protected posts from searches without access', 'keel-defaults' ),
			'help'      => __( 'Keeps password-protected posts out of search results for visitors who cannot read them.', 'keel-defaults' ),
			'detail'    => __( 'Keeps protected titles and excerpts out of site search unless the logged-in visitor can edit that post or has unlocked its password. Honors custom per-post capabilities and password-access filters. Does not change admin searches, direct links or stored content.', 'keel-defaults' ),
		),
		'hide_shortcode_residue'          => array(
			'label'     => __( 'Broken Shortcodes', 'keel-defaults' ),
			'statement' => __( 'Hide recognizable missing-shortcode markup from readers', 'keel-defaults' ),
			'help'      => __( 'Hides leftover [shortcode] tags from readers when the plugin that handled them is gone.', 'keel-defaults' ),
			'detail'    => __( 'Keeps enclosed text and stored content. People who can edit the post still see the residue. Site Health reports recent affected posts and tag names without scanning posts. Bare bracketed words, code examples, registered shortcodes and REST output stay unchanged. Does not restore missing plugin output.', 'keel-defaults' ),
		),
		'post_revisions_limit'            => array(
			'label'         => __( 'Post Revision Retention', 'keel-defaults' ),
			'unit'          => __( 'revisions', 'keel-defaults' ),
			'unit_singular' => __( 'revision', 'keel-defaults' ),
			'states'        => array(
				'-1' => __( 'Unlimited', 'keel-defaults' ),
				'0'  => __( 'Disabled', 'keel-defaults' ),
			),
			'help'          => __( 'How many revisions to keep for each post. Enter -1 for unlimited or 0 for none.', 'keel-defaults' ),
			'detail'        => __( 'Maximum revisions WordPress keeps for each post. Enter <code>-1</code> for unlimited or <code>0</code> to disable revisions. Changing this governs future saves; it does not immediately delete revisions already stored. A numeric or false <code>WP_POST_REVISIONS</code> value in <code>wp-config.php</code> takes precedence.', 'keel-defaults' ),
		),
		'force_classic_editor'            => array(
			'label'     => __( 'Classic Editor', 'keel-defaults' ),
			'statement' => __( 'Use the Classic editor instead of the block editor', 'keel-defaults' ),
			'help'      => __( 'Uses the Classic editor and the classic Widgets screen instead of the block editor.', 'keel-defaults' ),
			'detail'    => __( 'Restores the pre-block editing experience for posts, pages, and custom post types, plus the classic Widgets screen. Front-end display of existing block content is unaffected, and on a block theme the Site Editor stays available. Off by default.', 'keel-defaults' ),
		),
		'lowercase_upload_filenames'      => array(
			'label'     => __( 'Upload Filenames', 'keel-defaults' ),
			'statement' => __( 'Lowercase new upload filenames', 'keel-defaults' ),
			'help'      => __( 'Lowercases the names of new uploads.', 'keel-defaults' ),
			'detail'    => __( 'Avoids case-sensitivity surprises when files move between case-insensitive local/staging and case-sensitive Linux production. On by default; only affects new uploads.', 'keel-defaults' ),
		),
		'media_sizes_panel'               => array(
			'label'     => __( 'Image Sizes', 'keel-defaults' ),
			'statement' => __( 'Show generated image sizes on attachments', 'keel-defaults' ),
			'help'      => __( 'Lists each generated image size on the attachment edit screen.', 'keel-defaults' ),
			'detail'    => __( 'Adds a read-only panel to the attachment edit screen listing each generated image size with its dimensions, file size, and URL — a quick way to confirm what WordPress produced. On by default.', 'keel-defaults' ),
		),
		'mail_failure_notice'             => array(
			'label'     => __( 'Email Deliverability', 'keel-defaults' ),
			'statement' => __( 'Warn when site email looks broken', 'keel-defaults' ),
			'help'      => __( 'Warns administrators when site email looks broken.', 'keel-defaults' ),
			'detail'    => __( 'Warns administrators when site email looks broken: a risky default From address (invalid, or an example/local/test domain) on a non-local site, and a bulk password reset that sent zero emails — replacing WordPress’s misleading "success" notice. On by default.', 'keel-defaults' ),
		),
		'suppress_nonproduction_mail'     => array(
			'label'     => __( 'Non-Production Email', 'keel-defaults' ),
			'statement' => __( 'Stop outgoing email unless this is the production site', 'keel-defaults' ),
			'help'      => __( 'Holds back outgoing email on staging, development and local copies of the site.', 'keel-defaults' ),
			'detail'    => __( 'A database copied from production brings real addresses and whatever mail service production used. A cron run or a bulk action then emails real people from a staging site or a laptop. Does nothing on production, so it cannot be left on by mistake. Override per site with <code>KEEL_ALLOW_NONPRODUCTION_MAIL</code> in <code>wp-config.php</code> or the <code>keel_suppress_nonproduction_mail</code> filter.', 'keel-defaults' ),
		),
		'title_only_admin_search'         => array(
			'label'     => __( 'Admin Search', 'keel-defaults' ),
			'statement' => __( 'Search titles only in admin list tables', 'keel-defaults' ),
			'help'      => __( 'Admin list-table searches match titles only, which is faster on big sites.', 'keel-defaults' ),
		),
		'frontend_admin_bar_behavior'     => array(
			'label'   => __( 'Front-End Admin Bar', 'keel-defaults' ),
			'help'    => __( 'Shows, hides or auto-hides the toolbar at the top of the site for logged-in users.', 'keel-defaults' ),
			'detail'  => __( 'The WordPress toolbar shown across the top of the site for logged-in users. Hide it for non-admins or everyone, or auto-hide it so it slides out of the way and returns on hover or keyboard focus (desktop only).', 'keel-defaults' ),
			'choices' => array(
				''                => __( 'Leave unchanged (WordPress default)', 'keel-defaults' ),
				'hide_non_admins' => __( 'Hide for non-admins', 'keel-defaults' ),
				'hide_all'        => __( 'Hide for everyone', 'keel-defaults' ),
				'auto_hide'       => __( 'Auto-hide, reveal on hover or keyboard focus (desktop)', 'keel-defaults' ),
			),
		),
		'admin_menu_width'                => array(
			'label'  => __( 'Admin Menu Width', 'keel-defaults' ),
			'help'   => __( 'Sets the width of the left admin menu.', 'keel-defaults' ),
			'detail' => __( 'Sets the width of the left admin menu, useful when plugin menu labels are long. WordPress default is 160px. Leave unchanged and Keel sets no width at all; choose 160px to assert core\'s width over a theme, host, or plugin that has widened the menu.', 'keel-defaults' ),
			'labels' => array( __( 'Leave unchanged', 'keel-defaults' ), __( '160px (WordPress default)', 'keel-defaults' ), __( '200px', 'keel-defaults' ), __( '240px', 'keel-defaults' ), __( '280px', 'keel-defaults' ), __( '300px', 'keel-defaults' ) ),
		),
		'admin_list_tables'               => array(
			'label'   => __( 'Admin List Tables', 'keel-defaults' ),
			'help'    => __( 'Tidies admin list tables, and can add helper columns such as ID and Modified.', 'keel-defaults' ),
			'detail'  => __( 'Tidy sizes columns to their content, simplifies headings and dates, and initially hides optional columns where you haven’t saved a preference. Tidy + helper columns also adds ID, Image and Modified to post lists, file size to Media, and registration and last-login dates to Users. Where you haven’t saved a preference, Image starts visible; ID and Modified stay off until you tick them in Screen Options. Your saved Screen Options stay unchanged; use Screen Options to show or hide individual columns.', 'keel-defaults' ),
			'choices' => array(
				'unchanged'    => __( 'Leave unchanged', 'keel-defaults' ),
				'tidy'         => __( 'Tidy existing tables', 'keel-defaults' ),
				'tidy_helpers' => __( 'Tidy + helper columns', 'keel-defaults' ),
			),
		),
		'environment_indicator'           => array(
			'label'     => __( 'Environment Indicator', 'keel-defaults' ),
			'statement' => __( 'Show the current environment in the admin bar', 'keel-defaults' ),
			'help'      => __( 'Shows a label in the admin bar naming this site’s environment.', 'keel-defaults' ),
			'detail'    => __( 'Adds a color-coded label to the admin bar showing the current environment (Production, Staging, Development, or Local) from <code>wp_get_environment_type()</code>, or from the Environment setting when one is chosen — a quick guard against acting on the wrong site. Common local-development hosts are recognized automatically. Off by default.', 'keel-defaults' ),
		),
		'environment_override'            => array(
			'label'   => __( 'Environment', 'keel-defaults' ),
			'help'    => __( 'What Keel treats this site as, when <code>WP_ENVIRONMENT_TYPE</code> is wrong.', 'keel-defaults' ),
			'detail'  => __( 'What Keel treats this site as, for the environment indicator and for holding back non-production email. Automatic reads <code>WP_ENVIRONMENT_TYPE</code> and recognizes common local-development hosts. Choose an environment to override that when the site is mislabeled — for example, a live site whose <code>wp-config.php</code> was copied from a local install and still says <code>local</code>. This changes Keel only: WordPress and other plugins keep reading <code>WP_ENVIRONMENT_TYPE</code>, so fix that too.', 'keel-defaults' ),
			'choices' => array(
				'auto'        => __( 'Automatic (WordPress environment type)', 'keel-defaults' ),
				'production'  => __( 'Production', 'keel-defaults' ),
				'staging'     => __( 'Staging', 'keel-defaults' ),
				'development' => __( 'Development', 'keel-defaults' ),
				'local'       => __( 'Local', 'keel-defaults' ),
			),
		),
		'disable_remember_me'             => array(
			'label'     => __( 'Remember Me', 'keel-defaults' ),
			'statement' => __( 'Disable Remember Me and remove the login checkbox', 'keel-defaults' ),
			'help'      => __( 'Removes the Remember Me checkbox from the login form.', 'keel-defaults' ),
			'detail'    => __( 'Removes the Remember Me checkbox from the login form, so every login uses the Regular Session Length. Useful for shared or kiosk machines.', 'keel-defaults' ),
		),
		'session_regular_days'            => array(
			'label'         => __( 'Regular Session Length', 'keel-defaults' ),
			'unit'          => __( 'days', 'keel-defaults' ),
			'unit_singular' => __( 'day', 'keel-defaults' ),
			'help'          => __( 'How long a login stays signed in. WordPress’s default is 2 days.', 'keel-defaults' ),
		),
		'remember_me_days'                => array(
			'label'         => __( 'Remember Me Length', 'keel-defaults' ),
			'unit'          => __( 'days', 'keel-defaults' ),
			'unit_singular' => __( 'day', 'keel-defaults' ),
			'help'          => __( 'How long a remembered login stays signed in. WordPress’s default is 14 days.', 'keel-defaults' ),
			'detail'        => __( 'How long a remembered login stays signed in. WordPress’s default is 14 days. It cannot be shorter than the Regular Session Length.', 'keel-defaults' ),
		),
		'login_logo_behavior'             => array(
			'label'   => __( 'Login Logo', 'keel-defaults' ),
			'help'    => __( 'Keeps, removes, unlinks or replaces the WordPress logo on the login screen.', 'keel-defaults' ),
			'detail'  => __( 'The default logo links to wordpress.org, off your site. Left untouched by default, since changing the login screen out of the box is intrusive. Removing, unlinking, or replacing the logo always points the header link at your home page. Replacing uses the logo set in the Customizer, or the site icon if there is no logo; with neither set, the WordPress logo stays.', 'keel-defaults' ),
			'choices' => array(
				'keep_default' => __( 'Keep the WordPress logo and wordpress.org link (WordPress default)', 'keel-defaults' ),
				'remove_logo'  => __( 'Remove the logo and the wordpress.org link', 'keel-defaults' ),
				'unlink_logo'  => __( 'Keep the logo, drop the wordpress.org link', 'keel-defaults' ),
				'replace_logo' => __( 'Replace the logo with your site logo', 'keel-defaults' ),
			),
		),
		'throttle_heartbeat'              => array(
			'label'     => __( 'Heartbeat API', 'keel-defaults' ),
			'statement' => __( 'Slow background admin polling', 'keel-defaults' ),
			'help'      => __( 'Slows background admin polling, which also slows autosave and post-lock warnings.', 'keel-defaults' ),
			'detail'    => __( 'Slows admin polling to 60 seconds and drops it on the dashboard home. Off by default: Heartbeat also powers autosave and post-lock warnings, so enabling this will make them update less often.', 'keel-defaults' ),
		),
	);
}

/**
 * Group (fieldset) titles, in display order.
 *
 * @return string[]
 */
function keel_defaults_group_labels() {
	return array(
		'security'    => __( 'Security and Attack Surface', 'keel-defaults' ),
		'updates'     => __( 'Updates', 'keel-defaults' ),
		'content'     => __( 'Content and Public Surfaces', 'keel-defaults' ),
		'editor'      => __( 'Editor', 'keel-defaults' ),
		'media'       => __( 'Media', 'keel-defaults' ),
		'email'       => __( 'Email', 'keel-defaults' ),
		'ux'          => __( 'Admin and Front-End UX', 'keel-defaults' ),
		'login'       => __( 'Login and Sessions', 'keel-defaults' ),
		'branding'    => __( 'Branding', 'keel-defaults' ),
		'performance' => __( 'Performance', 'keel-defaults' ),
	);
}

/**
 * Section titles for grouped toggles.
 *
 * @return string[]
 */
function keel_defaults_section_labels() {
	return array(
		'rest'   => __( 'REST API', 'keel-defaults' ),
		'xmlrpc' => __( 'XML-RPC', 'keel-defaults' ),
	);
}
