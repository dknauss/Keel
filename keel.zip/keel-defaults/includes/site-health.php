<?php
/**
 * The Keel Site Health surface.
 *
 * @package Keel
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register Keel's read-only Site Health posture test.
 *
 * @param array $tests Registered Site Health tests.
 * @return array
 */
function keel_defaults_site_health_tests( $tests ) {
	if ( ! is_array( $tests ) ) {
		return $tests;
	}
	$tests['direct']['keel_registration_audit']        = array(
		'label' => __( 'Keel registration audit', 'keel-defaults' ),
		'test'  => 'keel_defaults_registration_health',
	);
	$tests['direct']['keel_defaults_posture']          = array(
		'label' => __( 'Keel Defaults', 'keel-defaults' ),
		'test'  => 'keel_defaults_site_health_posture',
	);
	$tests['direct']['keel_update_diagnostics']        = array(
		'label' => __( 'Update diagnostics', 'keel-defaults' ),
		'test'  => 'keel_defaults_site_health_update_diagnostics',
	);
	$tests['direct']['keel_defaults_conflicts']        = array(
		'label' => __( 'Setting conflicts', 'keel-defaults' ),
		'test'  => 'keel_defaults_site_health_conflicts',
	);
	$tests['direct']['keel_defaults_breach_screening'] = array(
		'label' => __( 'Password breach screening', 'keel-defaults' ),
		'test'  => 'keel_defaults_site_health_breach_screening',
	);
	if ( keel_defaults_enabled( 'require_strong_passwords' ) ) {
		$tests['direct']['keel_defaults_breached_passwords'] = array(
			'label' => __( 'Breached passwords at login', 'keel-defaults' ),
			'test'  => 'keel_defaults_site_health_breached_passwords',
		);
	}
	$tests['direct']['keel_defaults_login_answers'] = array(
		'label' => __( 'Login answers', 'keel-defaults' ),
		'test'  => 'keel_defaults_site_health_login_answers',
	);
	$tests['direct']['keel_defaults_environment']   = array(
		'label' => __( 'Environment type', 'keel-defaults' ),
		'test'  => 'keel_defaults_site_health_environment',
	);

	if ( keel_defaults_enabled( 'hide_shortcode_residue' ) ) {
		$tests['direct']['keel_defaults_shortcodes'] = array(
			'label' => __( 'Broken shortcodes', 'keel-defaults' ),
			'test'  => 'keel_defaults_site_health_shortcodes',
		);
	}

	// Only where there is a Jetpack connection to say something about. A check
	// that passes on every site without Jetpack is noise in the passed list.
	if ( '' !== keel_defaults_jetpack_xmlrpc_state() ) {
		$tests['direct']['keel_defaults_jetpack_xmlrpc'] = array(
			'label' => __( 'Jetpack and XML-RPC', 'keel-defaults' ),
			'test'  => 'keel_defaults_site_health_jetpack_xmlrpc',
		);
	}

	return $tests;
}

/**
 * Report whether the login forms confirm which accounts exist (#378).
 *
 * Good with Login Answers on; recommended with it off, since off reopens a
 * route Keel closes by default. Both states name what the setting covers and
 * what it doesn't, so a passing result is not read as more than it is.
 *
 * @return array Site Health result.
 */
function keel_defaults_site_health_login_answers() {
	$on = keel_defaults_enabled( 'uniform_login_answers' );

	$covered = '<p>' . esc_html__( 'Covered: failed sign-ins on the login form at wp-login.php (including the session-expired re-login and forms that post to it) and requests on its lost-password form.', 'keel-defaults' ) . '</p>';
	$not     = '<p>' . esc_html__( 'Not covered: registration, the profile and user-edit screens, the reset-link screens, response time (a real account still takes longer to answer), login attempt limiting, REST requests signed with an application password, XML-RPC, and login forms other plugins render themselves, such as WooCommerce My Account.', 'keel-defaults' ) . '</p>';
	$link    = keel_defaults_setting_link( 'uniform_login_answers', __( 'Login Answers', 'keel-defaults' ) );

	if ( $on ) {
		$label       = __( 'The login forms don’t confirm which accounts exist', 'keel-defaults' );
		$description = '<p>' . esc_html__( 'Every failed sign-in gets the same message, and every password reset request is answered "Check your email", whether or not the account exists.', 'keel-defaults' ) . '</p>';
	} else {
		$label       = __( 'The login forms confirm which accounts exist', 'keel-defaults' );
		$description = '<p>' . sprintf(
			/* translators: %s: link to the Login Answers setting. */
			esc_html__( 'The login form answers an unknown username, an unknown email address and a wrong password differently, and the lost-password form answers differently for real and unknown accounts. Turning on %s gives them one answer.', 'keel-defaults' ),
			$link // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built by keel_defaults_setting_link(), which escapes both halves.
		) . '</p>';
	}

	return array(
		'label'       => $label,
		'status'      => $on ? 'good' : 'recommended',
		'badge'       => array(
			'label' => __( 'Security', 'keel-defaults' ),
			'color' => $on ? 'blue' : 'orange',
		),
		'description' => $description . $covered . $not,
		'actions'     => $on ? '' : sprintf(
			'<p><a href="%s">%s</a></p>',
			esc_url( admin_url( 'options-general.php?page=keel' ) ),
			esc_html__( 'Review Keel settings', 'keel-defaults' )
		),
		'test'        => 'keel_defaults_login_answers',
	);
}

/**
 * Report whether WordPress, Keel and the site agree on what environment this is.
 *
 * The admin notices say the same things, but Site Health is where hosts,
 * support staff and audits look, and where a passing state can be shown too.
 * Worst state first: a live site labelled local, then an override covering for
 * that label, then an override ignored on a copied database.
 *
 * @return array Site Health result.
 */
function keel_defaults_site_health_environment() {
	$keel      = keel_defaults_current_environment();
	$wordpress = wp_get_environment_type();
	$link      = keel_defaults_setting_link( 'environment_override', __( 'Environment', 'keel-defaults' ) );
	$host      = keel_defaults_home_host();
	$site      = '<code>' . esc_html( '' !== $host ? $host : home_url() ) . '</code>';
	$stale     = '<p>' . sprintf(
		/* translators: 1: environment name, such as production. 2: the host the override was chosen on. 3: this site's host. 4: link to the Environment setting. */
		esc_html__( 'It says %1$s, but it was chosen on %2$s and this site is %3$s — most likely a copy of that site’s database. Keel is using the automatic environment instead, so a copy does not send real mail as if it were the live site. Choose the %4$s again here if this site needs one.', 'keel-defaults' ),
		'<strong>' . esc_html( keel_defaults_environment_override_stored() ) . '</strong>',
		'<code>' . esc_html( (string) get_option( KEEL_ENVIRONMENT_OVERRIDE_HOST_OPTION, '' ) ) . '</code>',
		$site,
		$link // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built by keel_defaults_setting_link(), which escapes both halves.
	) . '</p>';
	$result = array(
		/* translators: %s: environment name, such as production. */
		'label'       => sprintf( __( 'WordPress and Keel agree that this is a %s site', 'keel-defaults' ), $keel ),
		'status'      => 'good',
		'badge'       => array(
			'label' => __( 'Keel', 'keel-defaults' ),
			'color' => 'blue',
		),
		'description' => '<p>' . esc_html__( 'Keel’s environment indicator and its non-production email handling use the same environment WordPress reports, so the label you see and what Keel does with email match what other plugins see.', 'keel-defaults' ) . '</p>',
		'test'        => 'keel_defaults_environment',
	);

	if ( keel_defaults_environment_looks_mislabelled() ) {
		$result['status'] = 'critical';
		/* translators: %s: environment name, such as local. */
		$result['label']       = sprintf( __( 'This site looks live, but WordPress says it is %s', 'keel-defaults' ), $wordpress );
		$result['description'] = '<p>' . sprintf(
			/* translators: 1: environment name, such as local. 2: the site's address. 3: WP_ENVIRONMENT_TYPE. */
			esc_html__( '%3$s is set to %1$s, but this site is served from %2$s. Keel treats the site as %1$s, which can hold back its email, and other plugins may turn features off on a site they think is local.', 'keel-defaults' ),
			'<strong>' . esc_html( $wordpress ) . '</strong>',
			$site,
			'<code>WP_ENVIRONMENT_TYPE</code>'
		) . '</p>' . keel_defaults_environment_fix_advice();

		// A copied database can be both: say so here too, as the notices do.
		if ( keel_defaults_environment_override_is_stale() ) {
			$result['description'] .= '<p><strong>' . esc_html__( 'Keel’s environment override is being ignored on this site.', 'keel-defaults' ) . '</strong></p>' . $stale;
		}

		return $result;
	}

	if ( keel_defaults_environment_override_masks_label() ) {
		$result['status']      = 'recommended';
		$result['label']       = __( 'Keel’s Environment setting is covering for a wrong WordPress label', 'keel-defaults' );
		$result['description'] = '<p>' . sprintf(
			/* translators: 1: environment Keel uses, such as production. 2: environment WordPress reports, such as local. */
			esc_html__( 'Keel treats this site as %1$s, but WordPress still says %2$s. The setting changes only Keel: WordPress, Jetpack and other plugins still read the label, so they may keep features off — on WordPress.com, for one, a site labeled local stops accepting pingbacks.', 'keel-defaults' ),
			'<strong>' . esc_html( $keel ) . '</strong>',
			'<strong>' . esc_html( $wordpress ) . '</strong>'
		) . '</p>' . keel_defaults_environment_fix_advice() . '<p>' . sprintf(
			/* translators: %s: link to the Environment setting. */
			esc_html__( 'Once it is fixed, set Keel’s %s back to Automatic.', 'keel-defaults' ),
			$link // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built by keel_defaults_setting_link(), which escapes both halves.
		) . '</p>';

		return $result;
	}

	if ( keel_defaults_environment_override_is_stale() ) {
		$result['status']      = 'recommended';
		$result['label']       = __( 'Keel’s environment override is being ignored on this site', 'keel-defaults' );
		$result['description'] = $stale;

		return $result;
	}

	if ( keel_defaults_environment_override_is_redundant() ) {
		$result['description'] .= '<p>' . sprintf(
			/* translators: 1: environment name, such as production. 2: link to the Environment setting. */
			esc_html__( 'Keel’s %2$s is set to %1$s, which is what this site reports anyway. Consider setting it back to Automatic, so Keel follows the site if it ever changes — a leftover Production, for example, would go on sending mail from a copy that is meant to be staging.', 'keel-defaults' ),
			'<strong>' . esc_html( $keel ) . '</strong>',
			$link // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built by keel_defaults_setting_link(), which escapes both halves.
		) . '</p>';

		return $result;
	}

	// Only an override: a local-tool host that declares nothing is meant to hold mail back.
	if ( '' !== keel_defaults_environment_override() && $keel !== $wordpress && 'production' === $wordpress && keel_defaults_suppresses_mail() ) {
		$result['status'] = 'recommended';
		/* translators: %s: environment Keel uses, such as staging. */
		$result['label']       = sprintf( __( 'Keel treats this production site as %s and is holding back its email', 'keel-defaults' ), $keel );
		$result['description'] = '<p>' . sprintf(
			/* translators: 1: environment Keel uses, such as staging. 2: link to the Environment setting. */
			esc_html__( 'WordPress reports this site as production, but Keel’s %2$s is set to %1$s, and Keel holds back outgoing email on non-production sites. If this is the live site, its password resets, notifications and other email are not being sent. Set the Environment to Automatic or Production if that is not intended.', 'keel-defaults' ),
			'<strong>' . esc_html( $keel ) . '</strong>',
			$link // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built by keel_defaults_setting_link(), which escapes both halves.
		) . '</p>';

		return $result;
	}

	if ( $keel !== $wordpress ) {
		/* translators: 1: environment WordPress reports. 2: environment Keel uses. */
		$result['label']       = sprintf( __( 'Keel treats this %1$s site as %2$s', 'keel-defaults' ), $wordpress, $keel );
		$result['description'] = '<p>' . esc_html__( 'Keel’s environment indicator and non-production email handling follow Keel’s environment, either because of the Environment setting or because the site is served from a local development address and declares no environment of its own. WordPress core and other plugins still see the environment WordPress reports.', 'keel-defaults' ) . '</p>';
	}

	return $result;
}

/**
 * Report whether Keel's XML-RPC settings leave Jetpack reachable.
 *
 * Jetpack goes on reporting itself connected when WordPress.com can no longer
 * call into the site: the connection is checked from the site outwards, and the
 * refusal happens on the way in. So the site looks healthy while the plugin
 * list and settings writes fail on WordPress.com. Nothing else on the site
 * surfaces that, which is why this is a check rather than a line of help text.
 *
 * @return array Site Health result.
 */
function keel_defaults_site_health_jetpack_xmlrpc() {
	$state  = keel_defaults_jetpack_xmlrpc_state();
	$result = array(
		'label'       => __( 'Jetpack can reach this site over XML-RPC', 'keel-defaults' ),
		'status'      => 'good',
		'badge'       => array(
			'label' => __( 'Keel', 'keel-defaults' ),
			'color' => 'blue',
		),
		'description' => '<p>' . esc_html__( 'Keel refuses batched XML-RPC requests (system.multicall), which is how WordPress.com manages this site through Jetpack. Requests that Jetpack verifies as signed by WordPress.com are let through, so the connection keeps working. Every other multicall is still refused.', 'keel-defaults' ) . '</p>',
		'test'        => 'keel_defaults_jetpack_xmlrpc',
	);

	if ( 'open' === $state ) {
		$result['description'] = '<p>' . esc_html__( 'Batched XML-RPC requests (system.multicall) are allowed on this site, so the requests WordPress.com sends through Jetpack are not affected.', 'keel-defaults' ) . '</p>';

		return $result;
	}

	$silent = esc_html__( 'Jetpack can still report itself as connected while this is happening, because it checks the connection from this site outwards. On WordPress.com, the plugin list, settings changes and other actions on this site will fail.', 'keel-defaults' );

	if ( 'blocked' === $state ) {
		$result['status']      = 'critical';
		$result['label']       = __( 'Jetpack is connected, but the XML-RPC endpoint is blocked', 'keel-defaults' );
		$result['description'] = '<p>' . sprintf(
			/* translators: %s: link to the XML-RPC Endpoint setting. */
			esc_html__( 'WordPress.com reaches this site through XML-RPC, and Keel is set to refuse every XML-RPC request. Turn off the block under %s, or disconnect Jetpack if it is not needed.', 'keel-defaults' ),
			keel_defaults_setting_link( 'block_xmlrpc_endpoint', __( 'XML-RPC Endpoint', 'keel-defaults' ) ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built by keel_defaults_setting_link(), which escapes both halves.
		) . '</p><p>' . $silent . '</p>';

		return $result;
	}

	if ( 'refused' === $state ) {
		$result['status']      = 'recommended';
		$result['label']       = __( 'Requests from WordPress.com to Jetpack are being refused', 'keel-defaults' );
		$result['description'] = '<p>' . sprintf(
			/* translators: %s: link to the XML-RPC Multicall setting. */
			esc_html__( 'Keel refuses batched XML-RPC requests (system.multicall), which is how WordPress.com manages this site through Jetpack. This version of Jetpack does not offer the check Keel uses to recognize requests signed by WordPress.com, so Keel cannot let them through. Update Jetpack, or allow multicall under %s.', 'keel-defaults' ),
			keel_defaults_setting_link( 'xmlrpc_allow_multicall', __( 'XML-RPC Multicall', 'keel-defaults' ) ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built by keel_defaults_setting_link(), which escapes both halves.
		) . '</p><p>' . $silent . '</p>';
	}

	return $result;
}

/**
 * Human-readable current state of one setting, for the posture summary.
 *
 * @param array $field Schema field (structure).
 * @param mixed $value Current value.
 * @param array $s     Display strings for this field (choice/range labels).
 * @return string
 */
function keel_defaults_state_label( $field, $value, $s = array() ) {
	$type = isset( $field['type'] ) ? $field['type'] : 'toggle';

	if ( 'toggle' === $type ) {
		return ( 'yes' === $value ) ? __( 'On', 'keel-defaults' ) : __( 'Off', 'keel-defaults' );
	}
	if ( 'select' === $type ) {
		if ( '' === $value ) {
			return __( 'Unchanged', 'keel-defaults' );
		}
		return isset( $s['choices'][ $value ] ) ? (string) $s['choices'][ $value ] : (string) $value;
	}
	if ( 'multiselect' === $type ) {
		$vals = array_map( 'strval', (array) $value );
		return empty( $vals ) ? __( 'None', 'keel-defaults' ) : implode( ', ', $vals );
	}
	if ( 'range' === $type ) {
		$values = isset( $field['values'] ) ? array_map( 'strval', array_values( $field['values'] ) ) : array();
		$labels = isset( $s['labels'] ) ? array_values( $s['labels'] ) : array();
		$idx    = array_search( (string) $value, $values, true );
		return ( false !== $idx && isset( $labels[ $idx ] ) ) ? (string) $labels[ $idx ] : (string) $value;
	}

	/*
	 * A bare number is not a state. The settings screen prints the unit beside the
	 * input, so "14" reads as days there and nowhere else; in Site Health and in
	 * the Status summary it arrived as "Remember Me Length: 14".
	 *
	 * Both number fields are days and the minimum is 1, so "1 days" is reachable
	 * and this needs _n() rather than a suffix. Hard-coding the unit here is safe
	 * only for as long as that stays true, so tests/site-health.php asserts it and
	 * names this function when it stops being true.
	 */
	if ( 'number' === $type ) {
		$key = (string) (int) $value;
		if ( isset( $s['states'][ $key ] ) ) {
			return (string) $s['states'][ $key ];
		}

		$number   = (int) $value;
		$singular = isset( $s['unit_singular'] ) ? (string) $s['unit_singular'] : ( isset( $s['unit'] ) ? (string) $s['unit'] : '' );
		$plural   = isset( $s['unit'] ) ? (string) $s['unit'] : $singular;
		$unit     = 1 === $number ? $singular : $plural;

		return trim( number_format_i18n( $number ) . ' ' . $unit );
	}

	return (string) $value;
}

/**
 * Keel's Site Health posture result: a read-only, grouped summary of every
 * default's current state.
 *
 * Intentionally informational — a toggle turned off is reported, not nagged,
 * because these are the site owner's deliberate choices. The overall status
 * escalates to "recommended" only for a couple of unambiguous security items
 * (strong passwords, REST user-discovery restriction), never for the opinionated
 * UX or content toggles.
 *
 * @return array
 */
function keel_defaults_posture_by_group() {
	$schema  = keel_defaults_schema();
	$strings = keel_defaults_strings();

	$by_group = array();

	foreach ( $schema as $key => $field ) {
		// Same rule as the settings screen: do not report a posture on a
		// feature this WordPress does not have. Site Health is read as the
		// answer to "what is this plugin doing to my site?", and a row for a
		// setting with nothing to act on is a wrong answer.
		if ( ! keel_defaults_key_supported( $key ) ) {
			continue;
		}

		$group = isset( $field['group'] ) ? $field['group'] : 'other';
		$s     = isset( $strings[ $key ] ) ? $strings[ $key ] : array();
		$value = keel_defaults_get( $key );
		if ( in_array( $key, array( 'plugin_auto_update_policy', 'theme_auto_update_policy' ), true ) ) {
			$value = keel_defaults_extension_update_policy( 'plugin_auto_update_policy' === $key ? 'plugin' : 'theme' );
			$value = keel_defaults_config_locked_value( $key, $value );
		}
		$state = keel_defaults_state_label( $field, $value, $s );

		// "Leave unchanged" is true of Keel and misleading about the site when
		// Jetpack is the one setting the width. Say so on the row itself; this is
		// an inventory, and the row is where the width gets read.
		if ( 'admin_menu_width' === $key && keel_defaults_jetpack_sets_menu_width() ) {
			/* translators: %s: the setting's current state, such as "Leave unchanged". */
			$state = sprintf( __( '%s (Jetpack\'s WordPress.com menu styling sets 272px)', 'keel-defaults' ), $state );
		}

		$by_group[ $group ][] = array(
			'key'   => $key,
			'label' => isset( $s['label'] ) ? $s['label'] : $key,
			'state' => $state,
		);
	}

	return $by_group;
}

/**
 * The same summary, as Site Health → Info.
 *
 * The Status tab was the wrong home for this and that is why nobody could find
 * it. A passing test is filed inside the collapsed "Passed tests" accordion at
 * the bottom of the page, so on a correctly configured site — the common case —
 * the summary is behind a fold with nothing pointing at it.
 *
 * Info is where WordPress keeps inventories: always expanded, copyable as a
 * block, and the first thing anyone asks for in a support thread. A read-only
 * list of every default and its state is an inventory, not a health warning.
 *
 * The Status test stays. It answers a different question — is anything actually
 * wrong — and it is the one that should be quiet when the answer is no.
 *
 * @param array $info Debug information sections.
 * @return array
 */
function keel_defaults_debug_information( $info ) {
	if ( ! is_array( $info ) ) {
		return $info;
	}

	$groups = keel_defaults_group_labels();
	$fields = array();

	/*
	 * One row per group, not per default. Naming the group on all 38 rows put
	 * "Security and Attack Surface: " in front of nine of them and made the
	 * column that should scan fastest the one carrying the most repetition.
	 *
	 * Core renders an array value as a definition list inside the value cell, so
	 * the group is stated once and its defaults sit under it. That is as close as
	 * the filter reaches: wp-admin/site-health-info.php emits a fixed two columns
	 * and passes both through esc_html, so a third column, a row-spanning cell
	 * and a bold group name are all unavailable here. The clipboard export
	 * indents nested values the same way, so a pasted report groups too.
	 */
	foreach ( keel_defaults_posture_by_group() as $group_key => $items ) {
		$states = array();

		foreach ( $items as $item ) {
			$states[ $item['label'] ] = $item['state'];
		}

		$fields[ $group_key ] = array(
			'label' => isset( $groups[ $group_key ] ) ? $groups[ $group_key ] : $group_key,
			'value' => $states,
		);
	}

	$info[ KEEL_DEFAULTS_INFO_SECTION ] = array(
		'label'       => __( 'Keel Defaults', 'keel-defaults' ),
		'description' => sprintf(
			/* translators: %s: link to the Keel settings screen. */
			__( 'Every default Keel manages and its current state on this site. Read-only — change them under %s.', 'keel-defaults' ),
			keel_defaults_setting_link( '', __( 'Settings → Site Defaults', 'keel-defaults' ) )
		),
		'fields'      => $fields,
	);

	return $info;
}

/**
 * Posture summary for Site Health → Status.
 *
 * @return array
 */
function keel_defaults_site_health_posture() {
	$groups   = keel_defaults_group_labels();
	$by_group = keel_defaults_posture_by_group();

	$strong_ok = keel_defaults_enabled( 'require_strong_passwords' );
	$rest_ok   = keel_defaults_enabled( 'restrict_rest_user_discovery' );
	$status    = ( $strong_ok && $rest_ok ) ? 'good' : 'recommended';

	$description = '<p>' . sprintf(
		/* translators: %s: link to the Keel settings screen. */
		esc_html__( 'Current state of the defaults Keel manages on this site — a read-only summary of your choices under %s, not a warning.', 'keel-defaults' ),
		keel_defaults_setting_link( '', __( 'Settings → Site Defaults', 'keel-defaults' ) ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built by keel_defaults_setting_link(), which escapes both halves.
	) . '</p>';

	foreach ( $groups as $group_key => $group_label ) {
		if ( empty( $by_group[ $group_key ] ) ) {
			continue;
		}
		$description .= '<p><strong>' . esc_html( $group_label ) . '</strong></p><ul>';
		foreach ( $by_group[ $group_key ] as $item ) {
			$description .= '<li>' . esc_html( $item['label'] ) . ' — ' . esc_html( $item['state'] ) . '</li>';
		}
		$description .= '</ul>';
	}

	if ( 'recommended' === $status ) {
		$notes = array();
		if ( ! $strong_ok ) {
			$notes[] = esc_html__( 'Strong passwords are off, so privileged accounts can set weak or breached passwords.', 'keel-defaults' );
		}
		if ( ! $rest_ok ) {
			$notes[] = esc_html__( 'REST user discovery is open, so anonymous visitors can enumerate usernames.', 'keel-defaults' );
		}
		$description .= '<p><strong>' . esc_html__( 'Worth a look:', 'keel-defaults' ) . '</strong> ' . esc_html( implode( ' ', $notes ) ) . '</p>';
	}

	return array(
		'label'       => ( 'good' === $status )
			? __( 'Keel defaults are in place', 'keel-defaults' )
			: __( 'Some Keel security defaults are off', 'keel-defaults' ),
		'status'      => $status,
		'badge'       => array(
			'label' => __( 'Security', 'keel-defaults' ),
			'color' => ( 'good' === $status ) ? 'green' : 'orange',
		),
		'description' => $description,
		'actions'     => sprintf(
			'<p><a href="%s">%s</a></p>',
			esc_url( admin_url( 'options-general.php?page=keel' ) ),
			esc_html__( 'Review Keel settings', 'keel-defaults' )
		),
		'test'        => 'keel_defaults_posture',
	);
}

/**
 * What Keel uses a policy hook for, in the settings screen's own words.
 *
 * An overlap row that names only the other plugins reads as though they were
 * the whole story. Naming Keel's side lets the reader judge the overlap: Keel
 * on `user_has_cap` only removes `unfiltered_html`, which says at once whether
 * a plugin granting its own capabilities there could matter.
 *
 * @param string $hook Hook name.
 * @return string The setting labels, semicolon-separated, or ''.
 */
function keel_defaults_overlap_purpose( $hook ) {
	$settings = keel_defaults_hook_settings( $hook );
	$strings  = keel_defaults_strings();
	$purposes = array();

	/*
	 * The setting's label, the name it has on the settings screen, and never its
	 * checkbox statement. The "Not taking effect" line above these rows names
	 * settings by label, and a row that switched to the statement called one
	 * setting two things in one panel: "XML-RPC Remote Publishing" there,
	 * "Allow remote publishing (blogging apps)" here. A statement also
	 * describes its toggle switched on, which Keel holding a hook does not
	 * imply.
	 */
	foreach ( $settings as $setting ) {
		if ( ! empty( $strings[ $setting ]['label'] ) ) {
			$purposes[] = $strings[ $setting ]['label'];
		}
	}

	return implode( '; ', $purposes );
}

/**
 * One <li> per contested hook, naming what is contesting it.
 *
 * Extracted only because the report emits the same list twice under different
 * headings, and a second copy is how the two would drift apart.
 *
 * @param array<string, string[]> $conflicts Hook => plugin directory names.
 * @return string
 */
function keel_defaults_conflict_list( $conflicts ) {
	$out = '';

	foreach ( $conflicts as $hook => $hook_plugins ) {
		/*
		 * The untraceable marker is not a plugin name and must not be printed as
		 * one. Rendering the raw list produced "comments_open — callbacks from
		 * Unattributed callback", which reads as a plugin called "Unattributed
		 * callback" — and a handful of those rows reads as a handful of plugins,
		 * none of them the one the notice actually named.
		 */
		$unnamed = in_array( KEEL_DEFAULTS_UNATTRIBUTED, $hook_plugins, true );
		$named   = array_map( 'keel_defaults_plugin_name', array_values( array_diff( $hook_plugins, array( KEEL_DEFAULTS_UNATTRIBUTED ) ) ) );

		if ( $named && $unnamed ) {
			$text = sprintf(
				/* translators: %s: comma-separated plugin names. */
				esc_html__( 'used by %s, and by code Keel cannot trace to a plugin', 'keel-defaults' ),
				esc_html( implode( ', ', $named ) )
			);
		} elseif ( $named ) {
			$text = sprintf(
				/* translators: %s: comma-separated plugin names. */
				esc_html__( 'used by %s', 'keel-defaults' ),
				esc_html( implode( ', ', $named ) )
			);
		} else {
			$text = esc_html__( 'used by code Keel cannot trace to a plugin', 'keel-defaults' );
		}

		$purpose = keel_defaults_overlap_purpose( $hook );

		if ( '' !== $purpose ) {
			$text = sprintf(
				/* translators: 1: what Keel uses the hook for, such as "Limit raw HTML and JavaScript to Administrators". 2: what else uses it, such as "used by gravityforms". */
				esc_html__( 'Keel setting: %1$s; also %2$s', 'keel-defaults' ),
				esc_html( $purpose ),
				$text
			);
		}

		$out .= '<li><code>' . esc_html( $hook ) . '</code> — ' . $text . '</li>';
	}

	return $out;
}

/**
 * Report passive, sampled evidence about the shared breach-screening transport.
 *
 * Missing evidence is not proof of clean passwords. Local admission limits and
 * provider failures both leave the password verdict unknown. Network-wide
 * activity is visible only to network managers.
 *
 * @return array
 */
function keel_defaults_site_health_breach_screening() {
	$result = array(
		'label'       => __( 'No breach-screening failures recorded', 'keel-defaults' ),
		'status'      => 'good',
		'badge'       => array(
			'label' => __( 'Keel', 'keel-defaults' ),
			'color' => 'blue',
		),
		'description' => '<p>' . esc_html__( 'New passwords are screened against the Have I Been Pwned corpus, and nothing has reported a failure.', 'keel-defaults' ) . '</p>',
		'test'        => 'keel_defaults_breach_screening',
	);

	if ( ! current_user_can( 'view_site_health_checks' ) ) {
		$result['description'] = '';
		return $result;
	}

	// Nothing to say when the feature is off. A site that has switched breach
	// screening off has not got a problem, it has made a choice.
	if ( ! keel_defaults_enabled( 'require_strong_passwords' ) ) {
		$result['label']       = __( 'Password breach screening is switched off', 'keel-defaults' );
		$result['description'] = '<p>' . sprintf(
			/* translators: %s: link to the Password Strength setting. */
			esc_html__( 'Strong passwords are not being required, so nothing is screened against known breaches. Turn on %s to enable it.', 'keel-defaults' ),
			keel_defaults_setting_link( 'require_strong_passwords', __( 'Password Strength', 'keel-defaults' ) ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built by keel_defaults_setting_link(), which escapes both halves.
		) . '</p>';

		return $result;
	}

	/*
	 * The filter as well as the constant. Reporting only the constant meant a
	 * site using the documented `keel_disable_hibp` filter was told screening
	 * was fine when nothing was being screened at all.
	 *
	 * Passed an empty password because there is none to screen here; a filter
	 * deciding per-password cannot be answered by a status check, and one
	 * switching the feature off wholesale — which is what this is looking for —
	 * does not care.
	 */
	if ( ( defined( 'KEEL_DISABLE_HIBP' ) && KEEL_DISABLE_HIBP )
		|| (bool) apply_filters( 'keel_disable_hibp', false, '' ) ) {
		$result['label']       = __( 'Password breach screening is switched off in code', 'keel-defaults' );
		$result['description'] = '<p>' . wp_kses(
			__( 'Length and the other password rules still apply, but the <code>KEEL_DISABLE_HIBP</code> constant or the <code>keel_disable_hibp</code> filter is stopping the breach lookup. This is deliberate configuration, not a fault.', 'keel-defaults' ),
			array( 'code' => array() )
		) . '</p>';

		return $result;
	}

	// One passive read: no initialization, refill, HTTP, or diagnostic writes.
	$evidence = keel_hibp_budget_evidence();
	$shared   = is_multisite();
	$private  = $shared && ! current_user_can( 'manage_network_options' );
	$failure  = $evidence['failure'];
	$success  = $evidence['success'];
	$degraded = ! $evidence['available'] || null !== $failure;

	if ( $private ) {
		$result['status']      = $degraded ? 'recommended' : 'good';
		$result['label']       = __( 'Password breach-screening coverage is unknown', 'keel-defaults' );
		$result['description'] = '<p>' . esc_html__( 'Screening is configured, but its coverage for a particular password is unknown. Transport evidence is shared across the network; a network manager can review it.', 'keel-defaults' ) . '</p>';
		return $result;
	}

	$result['label'] = __( 'Password breach screening has no sampled failures', 'keel-defaults' );
	$description     = '<p>' . ( $shared
		? esc_html__( 'This is network-shared screening transport evidence, not proof that a particular site’s last password was checked.', 'keel-defaults' )
		: esc_html__( 'This is screening transport evidence, not proof that every password was checked.', 'keel-defaults' ) ) . '</p>';

	if ( ! $evidence['available'] ) {
		$result['status'] = 'recommended';
		$result['label']  = __( 'Password breach-screening transport evidence is unavailable', 'keel-defaults' );
		$description     .= '<p>' . esc_html__( 'The shared lookup budget could not be read. Fresh lookup coverage is unknown; this does not establish a Have I Been Pwned outage.', 'keel-defaults' ) . '</p>';
	} elseif ( null !== $failure ) {
		$kinds = array(
			'budget_exhausted'   => __( 'the shared allowance for lookups was used up, or only the share kept for privileged accounts was left', 'keel-defaults' ),
			'lookup_busy'        => __( 'the shared lookup slots were busy', 'keel-defaults' ),
			'budget_unavailable' => __( 'the shared lookup budget was unavailable', 'keel-defaults' ),
			'unreachable'        => __( 'the service could not be reached', 'keel-defaults' ),
			'truncated'          => __( 'the reply was cut short before it could be read', 'keel-defaults' ),
			'malformed'          => __( 'the reply did not contain a valid complete range response', 'keel-defaults' ),
		);
		$kind  = $failure['kind'];
		if ( isset( $kinds[ $kind ] ) ) {
			$reason = $kinds[ $kind ];
		} elseif ( preg_match( '/^http_[0-9]{3}$/D', $kind ) ) {
			/* translators: %s: HTTP response status code. */
			$reason = sprintf( __( 'the service answered with HTTP %s', 'keel-defaults' ), substr( $kind, 5 ) );
		} else {
			$reason = __( 'the lookup could not complete', 'keel-defaults' );
		}
		$result['status'] = 'recommended';
		$result['label']  = __( 'Password breach screening has sampled unavailability', 'keel-defaults' );
		$description     .= '<p>' . sprintf(
			/* translators: 1: sampled lookup failure reason, 2: elapsed time since the sample. */
			esc_html__( 'A sampled fresh lookup was skipped or could not complete: %1$s. The sample was recorded %2$s ago. Samples are rate-limited, not counts of all skipped or failed checks.', 'keel-defaults' ),
			esc_html( $reason ),
			esc_html( human_time_diff( $failure['seen'] ) )
		) . '</p>';
	} else {
		$description .= '<p>' . esc_html__( 'No unavailability sample is retained. This does not establish that screening has run or that every lookup succeeded.', 'keel-defaults' ) . '</p>';
	}

	if ( null !== $success ) {
		$description .= '<p>' . sprintf(
			/* translators: %s: elapsed time since a validated live response. */
			esc_html__( 'The last recorded validated live response completed %s ago. This is historical transport evidence, not a guarantee of current availability.', 'keel-defaults' ),
			esc_html( human_time_diff( $success ) )
		) . '</p>';
		if ( null !== $failure && $success > $failure['seen'] ) {
			$description .= '<p>' . esc_html__( 'A later live response does not erase the earlier sampled unknown verdict or establish that every intervening check completed. The sample remains subject to the shared diagnostic sampling interval.', 'keel-defaults' ) . '</p>';
		}
	} else {
		$description .= '<p>' . esc_html__( 'No validated live response is recorded. Locally filtered verdicts do not establish live service recovery.', 'keel-defaults' ) . '</p>';
	}
	$description          .= '<p>' . esc_html__( 'An unknown breach verdict does not block a password change; the other password rules and their role exemptions still apply. This evidence does not establish that all passwords set after a failure went unchecked.', 'keel-defaults' ) . '</p>';
	$result['description'] = $description;

	return $result;
}

/**
 * Report other plugins competing for the same settings.
 *
 * Two plugins registered on the same policy hook do not error or log. WordPress
 * composes both callbacks in priority order, so their settings may agree or may
 * disagree. Registration proves only that both participate in the decision.
 *
 * The result names what is contesting what and deliberately does not say which
 * plugin to keep. That is a judgement about what the site needs, and a check
 * answering it would be Keel arguing for its own retention.
 *
 * @return array
 */
function keel_defaults_site_health_conflicts() {
	$report   = keel_defaults_policy_overlap_report();
	$overlaps = $report['structural'];
	$badge    = array(
		'label' => __( 'Keel', 'keel-defaults' ),
		'color' => 'blue',
	);
	$intro    = '<p>' . esc_html__( 'Some Keel settings work by adding a filter to a WordPress hook. Other plugins can add filters to the same hook. When they do, WordPress runs all the filters, and together they decide the result. Sharing a hook does not mean there\'s a conflict between Keel and the other plugins listed. That may be the case, but often each one has an isolated function and purpose.', 'keel-defaults' ) . '</p><p>' . esc_html__( 'Each item shows the hook name, the Keel setting that uses it, and the other plugins that use it too.', 'keel-defaults' ) . '</p>';

	/*
	 * The other half, and the one that answers "so is my setting working?".
	 *
	 * Where a plugin overrides a setting through one of WordPress's own helpers
	 * there is nobody to name — nothing records which plugin called add_filter().
	 * Keel can still see that its setting is not producing the value it asks
	 * for, because its own callbacks run when WordPress runs the filter. This is
	 * read from those observations; nothing is invoked to produce it.
	 */
	$divergences = keel_defaults_policy_divergences();

	if ( ! empty( $divergences ) ) {
		$intro .= '<p><strong>' . sprintf(
			/* translators: %s: comma-separated setting names, each followed by its hook. */
			esc_html__( 'Not taking effect: %s', 'keel-defaults' ),
			keel_defaults_hook_setting_names( array_keys( $divergences ) )
		) . '</strong></p><p>' . esc_html__( 'These settings were last seen producing a different value from the one configured here, so something else on this site is deciding them.', 'keel-defaults' ) . ' ';

		/*
		 * Say "Keel cannot say what" only when that is true.
		 *
		 * The sentence used to print whatever the overlap report found, so a
		 * site where the plugin overriding comments was named three lines
		 * further down was also told nobody could be named. Where every
		 * diverging hook has an attributable overlap, point at that list
		 * instead. It also said the other plugin turned a feature "off", which
		 * is backwards for the commonest case: a plugin reopening comments.
		 */
		if ( array() === array_diff_key( $divergences, $overlaps ) ) {
			$intro .= esc_html__( 'The plugins listed below for the same hooks are the place to look.', 'keel-defaults' ) . '</p>';
		} else {
			$intro .= esc_html__( 'Keel cannot always say what: a plugin that turns a feature on or off using one of WordPress\'s own helper functions leaves nothing to trace it back by. Your active plugins are the place to look.', 'keel-defaults' ) . '</p>';
		}
	}
	$details = '';

	if ( ! empty( $report['unconfirmed'] ) ) {
		$details .= '<p><strong>' . esc_html__( 'Shared, for information only', 'keel-defaults' ) . '</strong> ' . esc_html__( 'Keel has not confirmed a conflict on any of these. On these hooks, each plugin usually adds its own part without undoing the others — for example, several plugins each granting their own permissions. Or Keel could not tell which plugin the code belongs to. No action is needed unless one of these Keel settings is not working as expected.', 'keel-defaults' ) . '</p><ul>';
		$details .= keel_defaults_conflict_list( $report['unconfirmed'] ) . '</ul>';

		if ( preg_grep( '/^' . preg_quote( KEEL_DEFAULTS_MU_PLUGIN_PREFIX, '/' ) . '/', array_merge( ...array_values( $report['unconfirmed'] ) ) ) ) {
			$details .= '<p>' . esc_html__( 'Must-use plugins are installed by a host or a developer and cannot be turned off from the Plugins screen, so Keel lists them here and shows no notice about them.', 'keel-defaults' ) . '</p>';
		}
	}

	if ( empty( $overlaps ) ) {
		/*
		 * Nothing to name is not the same as nothing wrong.
		 *
		 * The status was decided by the attributable overlaps alone, so a site
		 * where the only finding was a setting not taking effect got "good" and
		 * "No attributable policy overlap was found" printed above a paragraph
		 * saying something else was deciding that setting. A green badge over
		 * those words is the one combination guaranteed not to be read — and
		 * the untraceable override is exactly the case with no overlap to
		 * report, so the two conditions coincide rather than being rare
		 * together.
		 */
		if ( ! empty( $divergences ) ) {
			return array(
				'label'       => __( 'A setting is not taking effect', 'keel-defaults' ),
				'status'      => 'recommended',
				'badge'       => $badge,
				'description' => $intro . $details,
				'test'        => 'keel_defaults_conflicts',
			);
		}

		/*
		 * The same argument, for the case with nobody to name at all.
		 *
		 * A hook shared with a callback that cannot be traced is still a finding
		 * — the Dashboard notice reports it and links here. Deciding the status
		 * on attributable overlaps alone answered 'good' and printed "No
		 * attributable policy overlap was found" above the very list the notice
		 * had promised. True of attributable overlaps; read as "nothing here" by
		 * anyone who arrived from the notice.
		 *
		 * 'good' also decided *where* it rendered. A passing test goes inside the
		 * collapsed "Passed tests" accordion, so the finding sat behind a fold,
		 * under a green badge, beneath a headline denying it. 'recommended' puts
		 * it in the visible list where the notice said it would be.
		 *
		 * Gated on the same helper the notice counts, so the two cannot disagree
		 * about whether there is anything to see.
		 */
		$unattributed = keel_defaults_unattributed_hooks();

		if ( ! empty( $unattributed ) ) {
			return array(
				'label'       => _n(
					'A Keel setting is also affected by code Keel cannot identify',
					'Some Keel settings are also affected by code Keel cannot identify',
					count( $unattributed ),
					'keel-defaults'
				),
				'status'      => 'recommended',
				'badge'       => $badge,
				'description' => $intro . $details,
				'test'        => 'keel_defaults_conflicts',
			);
		}

		return array(
			'label'       => __( 'No other plugin was found changing Keel\'s settings', 'keel-defaults' ),
			'status'      => 'good',
			'badge'       => $badge,
			'description' => $intro . $details,
			'test'        => 'keel_defaults_conflicts',
		);
	}

	$plugins = array();
	$themes  = array();
	foreach ( $overlaps as $hook_plugins ) {
		foreach ( $hook_plugins as $plugin ) {
			if ( 0 === strpos( $plugin, KEEL_DEFAULTS_THEME_PREFIX ) ) {
				$themes[ substr( $plugin, strlen( KEEL_DEFAULTS_THEME_PREFIX ) ) ] = true;
			}
			$plugins[ $plugin ] = true;
		}
	}

	// A theme on its own is not "more than one plugin", and nobody deactivates a
	// theme. Beside a plugin it stays in the one list, marked as a theme.
	if ( count( $themes ) === count( $plugins ) ) {
		$description = $intro . '<p><strong>' . sprintf(
			/* translators: %s: theme name, or a child theme and its parent, comma-separated. */
			esc_html__( 'Your theme may change the same settings as Keel: %s', 'keel-defaults' ),
			esc_html( implode( ', ', array_map( 'keel_defaults_theme_name', array_keys( $themes ) ) ) )
		) . '</strong></p><p>' . esc_html__( 'Your theme adds filters on the same WordPress hooks as some Keel settings, where whichever runs last can override the other. Although sharing a hook is not definitive evidence of a conflict, you should check that your theme\'s settings and Keel\'s are set up to achieve complementary outcomes.', 'keel-defaults' ) . '</p><ul>';
		$description .= keel_defaults_conflict_list( $overlaps ) . '</ul>' . $details;

		return array(
			'label'       => empty( $divergences ) ? __( 'Your theme may influence the same settings as Keel', 'keel-defaults' ) : __( 'A setting is not taking effect', 'keel-defaults' ),
			'status'      => 'recommended',
			'badge'       => $badge,
			'description' => $description,
			'test'        => 'keel_defaults_conflicts',
		);
	}

	$description = $intro . '<p><strong>' . sprintf(
		/* translators: %s: comma-separated plugin names. */
		esc_html__( 'Plugins that may change the same settings as Keel: %s', 'keel-defaults' ),
		esc_html( implode( ', ', array_map( 'keel_defaults_plugin_name', array_keys( $plugins ) ) ) )
	) . '</strong></p><p>' . esc_html__( 'These plugins add filters on the same WordPress hooks as some Keel settings, where the last plugin to run can override the others. Although sharing a hook is not definitive evidence of a conflict, you should check that their settings and Keel\'s are set up to achieve complementary outcomes.', 'keel-defaults' ) . '</p><ul>';
	$description .= keel_defaults_conflict_list( $overlaps ) . '</ul>' . $details;

	/*
	 * A confirmed divergence keeps its headline when a plugin can be named.
	 *
	 * The named case read softer than the untraceable one: the same recorded
	 * divergence got "A setting is not taking effect" when nobody could be
	 * blamed and "More than one plugin may influence" when somebody could. The
	 * second is the more actionable finding and should not be the vaguer one.
	 */
	return array(
		'label'       => empty( $divergences ) ? __( 'More than one plugin may influence the same settings', 'keel-defaults' ) : __( 'A setting is not taking effect', 'keel-defaults' ),
		'status'      => 'recommended',
		'badge'       => $badge,
		'description' => $description,
		'test'        => 'keel_defaults_conflicts',
	);
}

/**
 * Style Keel's own section of Site Health → Info.
 *
 * Two columns is all `wp-admin/site-health-info.php` emits, and it passes both
 * cells through `esc_html`, so there is no markup lever here — the group name
 * cannot be marked up as a heading and cannot span rows. CSS is the only
 * mechanism, which is worth being explicit about rather than dressing up.
 *
 * What makes it safe rather than fragile is the scope. The id comes from our own
 * array key, so nothing here can reach another plugin's section or core's, and
 * if a future WordPress renames `.health-check-table` the rules stop matching
 * and the table renders in core's default style. Failure is a plain table, not a
 * broken one.
 *
 * `vertical-align` is the reason this exists. Each value cell holds a list of up
 * to nine defaults, and a middle-aligned row header floats to the centre of its
 * own list, level with nothing. Top alignment puts the group name beside the
 * first default under it.
 *
 * The weight is a partial departure, and the qualifier is the interesting half.
 * Core sets `.widefat th` to 400, but `.widefat.health-check-table th` to 600
 * inside `@media screen and (max-width: 782px)` — so below 782px every Info
 * section is already semibold and Keel simply matches, while above it Keel's
 * group names are the only bold ones on the page. Measured both ways rather than
 * read off the first rule that matched: the browser reported 600 for core's
 * section too, which was the narrow-viewport rule and nearly became a correction
 * in the wrong direction.
 *
 * Worth it because these are headings for the lists beside them rather than
 * field labels. It does mean the section stands out at desktop width, which is
 * where most people read it.
 *
 * @return string
 */
function keel_defaults_site_health_info_css() {
	return sprintf(
		'#health-check-accordion-block-%1$s .health-check-table th{font-weight:600;vertical-align:top}#health-check-accordion-block-%1$s .health-check-table td{vertical-align:top}',
		sanitize_html_class( KEEL_DEFAULTS_INFO_SECTION )
	);
}
