=== Keel Defaults ===
Contributors: dpknauss
Donate link: https://github.com/sponsors/dknauss
Tags: security, updates, site health, defaults, hardening
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 8.1
Stable tag: 0.10.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

47 sane WordPress defaults on one screen, plus a warning and a one-click fix to install when your version of WordPress is vulnerable.

== Description ==

A new WordPress site leaves a lot of small decisions to you: how strong passwords must be, when updates happen, what the outside world can see, what a copied test site is allowed to do. Keel Defaults makes those decisions sensibly from the start and puts all 47 defaults on one screen, in plain language, where you can change any of them.

**[Try Keel live in WordPress Playground](https://playground.wordpress.net/?blueprint-url=https://raw.githubusercontent.com/dknauss/Keel/main/playground/blueprint-stable.json)** — a temporary WordPress site opens in your browser with the current release of Keel already switched on. No hosting, installation, or account required.

= What Keel does for you =

* **Tells you when WordPress itself needs attention.** If your version of WordPress has known security holes, Keel says so in Site Health. When a fix exists for the version you are on, Keel names it and gives an administrator a button to install it. If no fix exists yet, it tells you that too, so you know to plan an upgrade.
* **Blocks passwords that have already leaked.** New and changed passwords are checked against passwords exposed in known data breaches, without the password ever leaving your site, and existing passwords are re-checked when people log in.
* **Stops your login screen revealing who has an account.** Out of the box, WordPress tells anyone who tries whether a username or email address is registered. Keel gives every failed login and every password-reset request the same answer, so the login form no longer confirms which accounts exist.
* **Stops test sites emailing real people.** Staging and local copies of your site send no email by default, so a copied database cannot email your customers, members, or clients by surprise.
* **Makes safer settings routine.** Stronger passwords, less exposed to the outside world, and practical choices for comments, revisions and uploads, without a pile of small single-purpose plugins.
* **Puts you in charge of updates.** One place to choose how WordPress, plugins and themes update, and an Updates screen that says plainly which policy the site follows and why.
* **Keeps email addresses out of public names.** WordPress shows a person's email address as their public name when their username is an email. Keel warns you when that happens, can give new and updated accounts safe public names, and fixes existing ones with a one-time cleanup.
* **Shows you exactly what it is doing.** One Site Health page lists every setting and its current state, and points out where another plugin overlaps with Keel or is overriding one of its settings.
* **Hands support a clean report.** Download a report of Keel's settings and checks to share with your developer or host, with no user data or site details in it.
* **Keeps a multisite network consistent.** A Super Admin can set chosen defaults for every site from one Network Policy screen. Each site's own choices are kept underneath and come back when the policy is lifted.
* **Tidies the admin lists, if you like.** An optional setting makes the posts and pages lists cleaner and gives them consistent dates. Your own Screen Options choices are kept.

= Who it is for =

Keel is especially useful if you build or look after many sites, as a freelancer, an agency, or the owner of a multisite network. It is just as useful if you have one site that matters too much to leave its basic safeguards to memory.

Keel is free, with no paid version, no account to create and no upsells in your dashboard.

= Safe to try, easy to undo =

Each setting has a control and an explanation under **Settings → Site Defaults**. Some settings depend on others or are managed by configuration or network policy. Keel does not edit or delete your existing posts, pages, media, or comments. The one change it makes to files by default is giving new uploads lowercase filenames. Turn a setting off and that behavior returns to WordPress; uninstall Keel and its settings are removed.

= Good to know before you activate =

Out of the box, Keel turns off comments, trackbacks, and pingbacks, hides public author archives, gives failed logins and password-reset requests one answer whether or not the account exists, and stops other sites displaying yours inside a frame. Nothing is deleted, and each of these is a switch you can turn back. The FAQ below explains each one.

== External services ==

Keel contacts two outside services. Neither is sent personal data.

= Have I Been Pwned: checking passwords against known breaches =

When the **Require strong passwords** default is enabled, Keel screens new passwords against the **Have I Been Pwned** Pwned Passwords range API (`https://api.pwnedpasswords.com`) and rejects passwords found in known breaches. It also re-checks existing passwords when people log in, and warns without blocking.

* **What is sent.** Only the first five characters of the password's SHA-1 hash, a method called k-anonymity. Never the password, never the full hash, and no personal data.
* **When.** Only while the default is on: when a password is set or changed, and at most once every 30 days per account when someone logs in with a password. Application passwords, XML-RPC and REST logins are not re-checked.
* **What is stored.** Nothing about the password or the reply. For login re-checks, two timestamps per account: when the password was last checked, and when it was found in a breach. Both are deleted when the password changes and when Keel is uninstalled. Lookups share a small allowance per site, so a burst of password changes cannot overload the service.
* **If the service is unreachable.** The check is skipped and the password change goes ahead under Keel's other password rules. Site Health tells you when checks could not run.
* **How to turn it off.** Turn off the strong-password default, add `define( 'KEEL_DISABLE_HIBP', true );` to `wp-config.php`, or use the `keel_disable_hibp` filter. Developers can tune the re-check interval and the roles it covers with filters listed in the plugin's documentation on GitHub.

Have I Been Pwned is operated by Troy Hunt; see https://haveibeenpwned.com/Privacy and https://haveibeenpwned.com/API/v3 for its terms and privacy policy.

= WordPress.org: checking whether your WordPress version is vulnerable =

Keel asks WordPress.org whether the installed version of WordPress has known vulnerabilities, using the core stable-check API (`https://api.wordpress.org/core/stable-check/1.0/`). This is WordPress.org's own service, on the same host WordPress already contacts for updates and translations, although WordPress itself never queries it.

* **What is sent.** No site data beyond the user-agent, which identifies the plugin and the site's home URL in the same way WordPress's own update requests identify the site.
* **How often.** Keel keeps the answer for a day. It asks again sooner only when WordPress's own update check offers a release that answer does not list yet, so a new security release is reported the day it ships.
* **If the service cannot be reached.** If WordPress.org is unreachable or answers with something unusable, the failure is remembered for five minutes so an outage does not slow down every admin screen, and Site Health reports that the status could not be determined rather than implying the site is fine.

WordPress.org's privacy policy is at https://wordpress.org/about/privacy/.

== Installation ==

1. In your WordPress dashboard, go to **Plugins → Add New**, search for "Keel Defaults", and install it. You can also upload the zip through **Plugins → Add New → Upload Plugin**, or copy the plugin folder into `wp-content/plugins/`.
2. Activate it. Keel's starting choices are applied on activation; nothing changes before that.
3. Visit **Settings → Site Defaults** to review the starting choices and adjust anything for this site.

Settings that could disrupt another service are off until you choose them, with one exception: Keel stops other sites displaying yours inside a frame. If your site is meant to be embedded, for example in an intranet dashboard, a visual-review service, or a kiosk or signage screen, set **Frame options** to "Leave unchanged" under Security and Attack Surface.

Deactivating stops Keel's behavior while keeping your choices for a future reactivation. Uninstalling removes its settings.

== Frequently Asked Questions ==

= What changes when I activate Keel? Will it break my site? =

Keel applies its starting choices and gives you one screen to review them. Comments, trackbacks, and pingbacks are turned off; public author archives are hidden; other sites cannot put yours inside a frame; and new uploads get lowercase filenames. Settings that could affect another service you rely on are left off until you enable them.

Nothing is deleted. Keel does not edit or remove your posts, pages, media, users, or comments. Disabling comments hides them and closes the forms; turning the setting off brings them back. Uninstalling removes only Keel's own settings.

Everything Keel does is visible and reversible, and each setting explains its practical effect before you change it. The default most likely to surprise you is frame protection: if another site or service is meant to display yours in a frame, that frame will usually show as a blank box. Set **Frame options** to "Leave unchanged" to allow it. Also review the settings after activation if a service publishes to your site through XML-RPC or depends on a feature you intend to turn off.

= Is Keel really free? =

Yes. There is no paid version, no account to create, no license key and no upsell in your dashboard. If Keel saves you time, you can support its maintenance through GitHub Sponsors.

= Will it slow my site down? =

No noticeable change. Most of Keel's defaults switch a WordPress feature off or set a header, which costs next to nothing. Its two outside lookups run only when a password is set or someone logs in, and once a day for the WordPress version check, and their answers are cached. Its reports are built in the admin, not on your public pages.

= Keel says this version is insecure. What should I do? =

Read the message in Site Health. Keel tells you whether a secure fix is available for the version of WordPress you are on, whether WordPress is offering it, and whether something is preventing automatic updates. If the install button is offered, an authorized administrator can use it to install that fix. If there is no secure fix, Keel says so clearly; plan an upgrade to a newer version rather than assuming one exists.

= Why has email stopped working on my staging site? =

Keel blocks outgoing email outside production by default. This protects real customers and clients when a live database is copied to staging or a local machine. It does not block email on your live site. Turn **Non-Production Email** off in **Settings → Site Defaults** when your test site needs to send email.

= Can I use Keel on client sites or multisite? =

Yes. Keel is built for independent sites, agencies, freelancers, and multisite networks. On a network, a Super Admin uses **Network Admin → Settings → Network Policy** to choose which defaults apply everywhere. The policy is visible and locked on each site, but it does not destroy the local choices underneath it; remove a policy later and each site returns to its own saved choice.

Passwords are the one setting that works differently on a network. The setting is stored per site, but WordPress keeps one list of users for the whole network, so a password set on any site becomes that person's password everywhere. For one rule across the network, set the password policy in Network Policy.

= Do I need Keel if I already use a security plugin such as Wordfence or Solid Security? =

They do different jobs, and they work well together. Firewall and malware-scanning plugins watch for attacks. Keel sets the everyday defaults that make a site a smaller target, and tells you when WordPress itself needs a security fix. Where two plugins control the same setting, choose one to own it. Keel shows likely overlaps in Site Health, so you can compare them instead of discovering a disagreement later.

= Does Keel control plugin and theme auto-updates? =

Yes, if you want it to. Plugins and themes each get one switch: turn auto-updates on for everything, off for everything, or leave WordPress's own per-item choices alone. Leave unchanged is the default, so nothing changes until you choose. On multisite, network policy or the main site decides, because every site shares the same plugin and theme files. Site Health shows which choice is in effect.

= Why does a failed login no longer say whether the username exists? =

WordPress's login form answers an unknown username, an unknown email address and a wrong password in three different ways, and its lost-password form answers "Check your email" only for real accounts. Together they tell anyone which usernames and addresses have accounts. Keel's **Login Answers** setting, on by default, gives every failed sign-in the same message and sends every reset request to "Check your email". Mail still goes only to real accounts, so someone who mistypes their address gets no email and no error; check the address and try again.

It covers the login form at `wp-login.php` (including the session-expired re-login and forms that post to it) and its lost-password form. It does not cover registration, the profile and user-edit screens, the reset-link screens, response time (a real account still takes a little longer to answer), login attempt limiting, REST requests signed with an application password, XML-RPC, or login forms other plugins render themselves, such as WooCommerce My Account. Errors other plugins add, such as lockouts or CAPTCHA, are shown as they wrote them. On multisite, a site's "Lost your password?" link leads to the main site's form when the site's address has no path of its own (every site on a subdomain network, and any site with its own domain), so the main site's setting, or network policy, decides that form. A site at a path such as `/blog/` serves its own.

= Why is there no password strength meter? =

WordPress's strength meter advises the person typing but cannot refuse a password, and passwords set through the REST API, WP-CLI, or a form without scripts never meet it. Keel instead checks length, known breaches, a blocklist, and personal details such as your own name on the server, where the checks cannot be bypassed.

= Can I download a report for support? =

Yes. Go to **Settings → Site Defaults** and use **Download JSON** under Export Settings and Diagnostics. The report shows your Keel settings and the results of its checks. It leaves out user details, site addresses, file paths and stored option values, so it is safe to send to a developer or host. Open it and look before you share it.

= Can I set these in code instead? =

Yes. Many defaults can be set with a `wp-config.php` constant or a filter, for example `KEEL_DISABLE_HIBP` or `KEEL_ALLOW_NONPRODUCTION_MAIL`. A constant wins over the settings screen, and the screen shows when a setting is being overridden. The full list is in the plugin's documentation on GitHub.

== Screenshots ==

1. Site Health → Status. Whether your version of WordPress has known vulnerabilities, which secure fix is available for it, and what WordPress itself is offering.
2. The Passwords help tab. How Keel's password rules work, and exactly what the breach check sends: five characters of a hash, never the password.
3. Site Health → Info. Every default and its current state on one page, so you can see what Keel is doing to your site without opening the settings.
4. Settings → Site Defaults. Every default is one switch with the reason it exists written beside it.
5. Network Admin → Settings → Network Policy. A Super Admin chooses safeguards for every site on a multisite network; each site's own choices return when the policy is lifted.

== Credits ==

[Austin Ginder](https://github.com/austinginder) of Anchor Hosting ([anchor.host](https://anchor.host) · [@anchorhost](https://github.com/anchorhost)) reviewed Keel for security, and the plugin is better for it. Thank you, Austin.

Keel grew out of [Better by Default](https://github.com/WPYEG/Better-by-Default), a teaching plugin that [Dan Knauss](https://github.com/dknauss) wrote for WPYEG, the Edmonton WordPress meetup. Keel keeps its core architecture. Better by Default is licensed GPL-3.0-or-later, and Dan, as its sole author, also licenses the code carried into Keel under GPL-2.0-or-later.

Keel also adapts hardening and admin defaults from Agency Experience (GPL-2.0-or-later), a hard fork of [10up Experience](https://github.com/10up/10up-experience) by 10up, so some of those defaults began as 10up's code. 10up and its contributors keep the copyright in that code, and 10up keeps its marks. Keel is not affiliated with or endorsed by 10up.

Keel is licensed GPL-2.0-or-later. The full text is in [LICENSE](https://github.com/dknauss/keel/blob/main/LICENSE).

== Support This Plugin ==

Keel is free and will stay free. If it saves you an afternoon of securing a new site, or keeps a staging server from emailing your client's customers, you can support its maintenance through [GitHub Sponsors](https://github.com/sponsors/dknauss).

Bug reports and feature requests are welcome on the issue tracker: [https://github.com/dknauss/keel/issues](https://github.com/dknauss/keel/issues). If you have found a security problem, please report it privately rather than in a public issue — SECURITY.md ships with the plugin and says how.

== Changelog ==

= 0.10.0 =
* Added: a Login Answers setting, on by default, including on sites that update. WordPress's login form answers an unknown username, an unknown email address and a wrong password with three different messages, and its lost-password form says "Check your email" only for a real account, so together they tell anyone which accounts exist. Keel now gives every failed sign-in at `wp-login.php` one message that repeats nothing typed, and answers every reset request with "Check your email". Mail still goes only to real accounts. Errors other plugins add, such as lockouts or CAPTCHA, are kept, and `wp_login_failed` fires as before, so login limiters count what they counted before. Registration, the profile and reset-link screens, response time, application passwords, XML-RPC and other plugins' login forms are not covered. On multisite, network policy can decide it for every site.
* Added: a Login Answers check in Site Health, which says what the setting covers and what it does not.
* Security: with Author Archives off, every author request now gets a plain 404: `/?author=N`, `/author/{slug}/` and their feeds, for real and unknown authors alike. Real authors used to be redirected to the home page while unknown ones got a 404, so `/?author=N` could still tell anyone which author IDs exist, and a redirect home for a page that is gone is a soft 404. With Author Archives on, an author with no published posts, or an author slug that names no one, now gets the same 404 as an unknown `?author=N` instead of a 200 page.
* Changed: the Random Post Redirects help matches WordPress 7.2 RC3. Core no longer runs a random-order query over every post on every request, though it still falls back to one when random samples miss, and `?random` on a search now returns to the search. The help now leads with what this setting is for: uncacheable public addresses the site never asked for, and posts an SEO plugin marks noindex coming up at random. Random author requests are closed by Author Archives, whatever this setting says.
* Changed: Keel now requires PHP 8.1 or newer. PHP 7.4 and 8.0 no longer get security fixes. WordPress does not offer an update to a site whose PHP is older than a plugin requires, so sites on PHP 7.4 or 8.0 stay on 0.9.2 until their PHP is upgraded.

= 0.9.2 =
* Security: on multisite, the main site's settings that every site shares now need a Super Admin. Where Network Policy leaves them unmanaged, the main site's three update policies, translation updates and Public Names apply to the whole network. A main-site administrator who cannot manage network options now sees them locked on Site Defaults, and a save keeps the stored values. Other sites, single sites and Network Policy are unchanged.
* Security: breach screening keeps no replies. A reply from Have I Been Pwned answers the check that asked for it and is then discarded, so no password, hash, hash prefix or reply is stored. The 64 rows earlier versions used are deleted when a site first loads this version. Checking the same password in two separate requests now spends the lookup allowance twice.
* Changed: half the breach-lookup allowance is kept for accounts that can write content or manage the site, so they can still be checked when the rest of the shared allowance is used up. With the default policy that is 5 of 10.
* Fixed: the login re-check screens the password as typed. WordPress hands the login form's password to plugins with slashes added, so a password containing a quote or a backslash was checked in a different form at login than when it was set.
* Changed: the Site Health check for email addresses in public names says whether Public Names is on, and links the setting and the one-time cleanup for people who can use them.

= 0.9.1 =
* Added: a Random Post Redirects setting, on by default, including on sites that update. WordPress 7.2 adds `/random/` addresses, and `?random` on any archive or search, that redirect to a random published post. Each one runs an uncached random-order query, and the author form confirms which author slugs exist even while author archives are off. Keel turns them off and clears the saved rewrite rules. With Author Archives off, random author requests find nothing whatever this setting says. Before WordPress 7.2 the setting does not appear.
* Added: a Public Names setting, off by default. When an account is created or updated by any route, a display name, nickname or author slug that repeats its login, email address or the part of the address before the @ is replaced with a safe one. Safe names people chose are kept, and logins, addresses and passwords never change. A one-time cleanup under Users → Public Names fixes existing accounts in resumable batches, and updates their past comments only when asked. Old author addresses are not redirected, because a redirect would confirm which address belongs to an account. On multisite, network policy or the main site's setting decides, because accounts are shared.
* Added: a Site Health check for email addresses in public names. When a username is an email address, WordPress copies it into the public display name and builds the author slug from it. The check counts affected accounts, lists up to 20 administrators and editors with published posts or approved comments (never by the address), and says which public places Keel's other settings already hide. It only reports.
* Changed: every setting's description is now one sentence of 25 words or fewer, so a screen reader no longer reads a paragraph on every control. The full explanations moved to a new Settings in Detail tab under Help, on Site Defaults and on Network Policy.
* Changed: the settings Help tabs are copy-edited, and a new Updates tab explains what the core, plugin and theme update settings decide and what they cannot promise.
* Changed: the auto-hidden admin bar now waits a moment before it appears and before it hides, so a quick move to the browser's tabs or toolbar no longer pops it open. Keyboard focus still shows it at once.
* Fixed: on WordPress.com, the Help Center hid Keel's Help tabs on Site Defaults. The Help link is back on that screen; the Help Center is unchanged.
* Accessibility: the Keel update policy title on the Updates screen is now a heading, and the breached-passwords table caption says how many accounts it lists, because VoiceOver did not announce that table's size.
* Performance: the check that notices another plugin overriding a setting reads Keel's settings once instead of once per setting, about three times faster, and a test confirms it adds no database queries on a healthy site.

= 0.9.0 =
* Added: Plugin Auto-Updates and Theme Auto-Updates settings: Enabled, Disabled, or Leave unchanged. Both default to Leave unchanged, which keeps WordPress's per-item choices. An explicit choice never rewrites those choices, and later filters still apply. There is no minor-only option, because plugin and theme version numbers carry no enforced meaning. On multisite, network policy decides for the shared files.
* Added: a Keel update policy notice on the Updates screen, just above Current version. It names the release line, explains the core update policy and where it comes from, links to the setting, and says plainly that a policy is not a delivery guarantee. WordPress's own text is left as it is.
* Added: an Update diagnostics panel in Site Health → Status. Plain tables show the release WordPress would install, the age of the last update-check attempt, scheduled checks, retained failure codes, and plugin and theme auto-update decisions. It is evidence for troubleshooting, not a health verdict or an installation schedule.
* Added: a sanitized JSON report of Keel's settings and diagnostics, downloaded from Settings → Site Defaults. It leaves out site and user identifiers, raw option records, callback paths and full plugin and theme lists. It is built for the download and never stored or sent anywhere. On multisite, network-management authority is required.
* Added: Site Health → Info lists the categories of data WordPress's normal update checks send to WordPress.org. It shows none of this site's values and makes no requests.
* Added: a Keel registration audit in Site Health. It checks that the protections for comment feeds, author feeds, author archives, attachment pages and session length are still registered where they can work. It reports what it finds and never runs other plugins' code or repairs anything.
* Added: on WordPress 7.1 and later, Site Health lists plugins that override Abilities API permission decisions. One such plugin can change who may run an ability, so each is listed for review, not reported as a fault.
* Changed: Admin List Columns is replaced by one Admin List Tables setting: Leave unchanged, Tidy existing tables, or Tidy + helper columns. Sites that had Admin List Columns on move to Tidy + helper columns, which also sizes post-list columns to their content, shortens known plugin column headings, shows Published dates with times and starts optional columns hidden. ID and Modified stay off until ticked in Screen Options. Saved Screen Options are never changed; choose Leave unchanged in Site Defaults to keep core's tables. In Tidy modes, Modified is sortable, sort arrows stay beside their headings and long values wrap.
* Fixed: with comments disabled, a comment could still be posted when another plugin reopened comments. Keel hid the form but the comment was stored. Submissions are now refused through the form, REST, XML-RPC and pingbacks; Notes keep working.
* Fixed: when another plugin overrides a setting and Keel can name it, Site Health now says "A setting is not taking effect" and points to that plugin, instead of a vaguer headline and a paragraph saying nothing could be named. The wording no longer assumes the other plugin turned a feature off.
* Fixed: the environment indicator disappeared from the admin bar at 782px and below, because WordPress hides every toolbar item it doesn't recognize on narrow screens. It now stays as a color-coded icon on phones and narrow windows.
* Changed: the Environments help tab is less than half its old length. The longer reasoning moved to docs/environment-detection.md. It now also says that the Environment setting changes what the indicator says, not whether it appears.
* Added: Password Strength now re-checks existing passwords at login, at most once every 30 days per account. A password found in a known breach still works, but its owner sees a warning on every admin screen until they change it. Administrators see a count and a linked list of affected accounts in Site Health, and a Breached passwords view on the Users screen, with links to each profile and to Send password reset. An unknown result is never recorded, and nothing is shown to anyone who cannot list users. Every role is checked; the `keel_password_rescreen_skip_roles` filter can leave subscribers out.
* Changed: Have I Been Pwned lookups now share an allowance per site, or per network on multisite: 10 requests to start, then one more each minute, with at most two at once. Up to 64 cached range responses are kept for up to 12 hours. When a fresh check cannot run, the breach result is unknown and the password change goes ahead under the other password rules.
* Security: on multisite, the older minor-update action also requires network-management permission, malformed setting values are rejected before conversion, and refused requests now answer with HTTP 403. A lab checks 135 authorization cases through real WordPress requests on every pull request.
* Fixed: locked settings, the update evidence tables and the Site Health cron and breached-account tables can be reached and scrolled by keyboard, with a visible focus outline, and the tables no longer widen the page on a 320px screen.
* Fixed: overlap diagnostics no longer load another plugin's classes just to name it, and attribution stays within the hook and storage scope it came from. The autoload report now names Keel's own options and core transients.
* Fixed: the core backport policy action linked to a settings section that no longer exists.
* Translations: every Canadian spelling in Keel now has an en_CA entry.

= 0.8.0 =
* Performance: Site Health identifies the ten largest observed autoloaded options, their byte sizes and probable owners with confidence and evidence. Collection runs in bounded, cached background batches. Option values are never exposed or cached; no options are deleted or given different autoload flags.
* Performance: Site Health identifies overdue and frequent stored cron events with probable owners, and relates core-update hooks to offer-cache age and retained failure codes. Arguments and error data are never retained; jobs, schedules and update policy are unchanged. External scheduling and incomplete coverage stay explicit; no update installation time is promised.
* Accessibility: cron report tables scroll in named, keyboard-focusable regions on narrow screens.
* Documentation: describe the 42 controls as configurable settings; some have dependencies or are centrally managed. Correct the release record: the update hook refreshes Keel's status cache without rewriting core update offers.

= 0.7.0 =
* Privacy (new default, also on for existing sites): hide password-protected posts from non-admin searches without access, while preserving per-post editing capabilities and unlocked-password access. Independently toggleable under Protected Search Results; does not change direct links or stored content.
* Content (new default, also on for existing sites): hide recognizable missing-shortcode markup from readers while keeping enclosed text and editors’ evidence. A paired Site Health report lists recently affected posts and missing tag names, without scanning posts or storing content. Bare bracketed words, examples and REST output stay unchanged. Independently toggleable under Broken Shortcodes.
* Admin: locked settings now carry a lock marker beside their label. A summary links to each locked setting and separates configuration locks from network policy. Links reveal hidden dependent controls and move keyboard focus.
* Accessibility: the drop-downs and number fields on the Network Policy screen now have names that screen readers announce. They were read out as unnamed controls.

Entries for 0.6.0 and earlier are in `changelog.txt` in the plugin's repository: [https://github.com/dknauss/keel/blob/main/changelog.txt](https://github.com/dknauss/keel/blob/main/changelog.txt). Versions before 0.5.9 were not published to the directory; their entries are the development history that led to the first release.

= 0.6.9 =
* Fixed: conflict diagnostics no longer mistake Keel for another plugin when its installation folder is a symlink to a differently named source directory.
* Improved: crowded conflict reports reuse plugin-root attribution work instead of repeating filesystem resolution for every callback. Site and network plugin changes still invalidate the mapping immediately.
* Changed: the vulnerable-core notice now explains when a fix should install automatically, why it may be a newer release than the same-line patch, and where to review the actual selection or upgrade options. It does not promise an installation time.
* Refactored: shared site/network controls, backport handling, password and breach screening, conflict diagnostics and configuration-policy helpers now have clearer module boundaries. Defaults, saved preferences, permissions and PHP 7.4 compatibility are preserved.
* Developer: precise data contracts and scoped PHPStan level-6 analysis cover nineteen modules, with contract regression fixtures and expanded real-WordPress, multisite, browser and installer verification. Development tooling is excluded from the installable package.
* Changed: translatable source strings use US English; translations remain available through WordPress.org language packs.

= 0.6.8 =
* Added: an Environment setting under Admin and Front-End UX. Automatic, the default, works as before. Choosing Production, Staging, Development or Local makes Keel use that instead, for the environment label and for holding back email on non-production sites. It applies only on the site where it was chosen, so a copy of the database on a laptop or staging site ignores it and never sends real email as the live site.
* Added: a warning when a live site says it is local. If WP_ENVIRONMENT_TYPE says local on a public address or on WordPress.com, Keel says so on every admin screen, because that label can hold back the site's email and make other plugins switch features off. A local wp-config.php copied to a live server, as a WordPress Studio push can do, is the usual cause. The warning names where the label comes from, the wp-config.php file Keel found and the WP-CLI command that fixes it. Keel never edits wp-config.php itself.
* Added: if the Environment setting is covering for a wrong label, Keel keeps a warning on screen until wp-config.php is fixed, because WordPress, Jetpack and the host still see the wrong label. Keel's settings screen also points out a setting that is no longer needed.
* Added: a Site Health check, Environment type, and the same warning in the Network Admin on multisite.
* Added: when Jetpack, not Keel, is setting the admin menu width (as on WordPress.com), the Admin Menu Width setting and Site Health now say so.
* Fixed: the block editor now follows the admin menu width. A wider menu covered the edge of the editor, and a narrower one left a blank strip beside it.
* Added: where Jetpack is active, the AI Connectors setting now says that Jetpack follows it. While it is on, which is the default, Jetpack's AI Assistant and its other AI features are switched off too.
* Changed: the Site Health report on plugins sharing Keel's settings now names must-use plugins and themes. On a managed host it used to say the code could not be traced to any plugin.
* Changed: the help for XML-RPC Multicall says to leave it off with Jetpack, because requests WordPress.com signs are still let through. The help for Frame Options says SAMEORIGIN can block previews embedded on WordPress.com.
* Changed: the line under Keel's name on the settings screen is now "Balanced defaults for steady sites."

= 0.6.7 =
* Fixed: with XML-RPC Multicall off, which is the default, a site connected to WordPress.com through Jetpack could be cut off from it. WordPress.com manages a connected site through multicall, so the plugin list and settings changes failed on WordPress.com while Jetpack still reported itself as connected. Keel now lets through the requests Jetpack verifies as signed by WordPress.com, and still refuses every other multicall.
* Fixed: a refused multicall went out as HTTP 405 instead of an XML-RPC fault, so clients reported a transport error. It is now an ordinary fault (code -32601) on HTTP 200.
* Added: on a site connected through Jetpack, Site Health now reports when Keel's XML-RPC settings stop WordPress.com from reaching it.
* Changed: the Site Health check for plugins sharing Keel's settings is rewritten in plain language. Each item now names the Keel setting involved and the other plugins by their names, not their folder names, and the report says outright that sharing a hook is not evidence of a conflict. Settings that are not taking effect are listed by name, with the hook shown for developers.
* Changed: the Site Health check on your WordPress version is titled "This version of WordPress core is not currently flagged as insecure", and on an older release line it names the line that will eventually be retired, such as "the 7.0 line".
* Fixed: in a right-to-left admin, dragging the admin menu width slider pushed the content from the wrong side, and the widened menu covered the start of every label. The preview now moves the content from the right.
* Fixed: on the network settings screen, the introduction was held to a narrow column while the settings below it used the full width. The cap is gone, so the introduction follows the Network Admin's own width like the rest of the screen.

= 0.6.6 =
* Security: with comments disabled, the REST API went on serving a single comment by ID (/wp/v2/comments/123). The guard added in 0.6.1 to close that route checked for a function WordPress does not define, so it never ran. It now checks correctly, and the route answers 404.
* Added: the WordPress.org listing has a Live Preview button. The blueprint behind it was in the repository all along, but the deploy held it back from the upload, so the listing never had one.
* Fixed: on the day a security release ships, Site Health could go on reporting your version as the latest for up to a day. Keel cached WordPress.org's release status for a day; it now fetches it again as soon as WordPress learns of a release the cached answer does not list.
* Fixed: a setting locked in wp-config.php showed the preference stored underneath the lock, not what the constant enforces. With WP_AUTO_UPDATE_CORE set to true, Core Auto-Updates read "Maintenance/security releases only" on a site installing every release. Locked controls now show what is in force, and when background updates are switched off entirely, the note names the constant that did it.
* Changed: a locked setting now looks locked. The note beneath it reads as a statement rather than a hint, the control itself is visibly inactive, and both are styled on the network settings screen too.
* Fixed: a folded admin menu stayed pinned open at a custom width. It now folds, and the width applies only above 960px, where WordPress does not fold the menu automatically. The live preview follows the same rules, so it no longer shows a width that saving would not apply.
* Changed: clearer wording throughout the core update and security patch messages, with constant, filter and file names shown as code.
* Fixed: with automatic updates switched off or held back by an earlier failed update, the Site Health patch panel said Keel would not offer a deliberate install directly above a working Install button. It now says the patch can still be installed deliberately, and keeps the refusal for the cases where Keel's installer really does refuse.
* Fixed: the security patch panel on Dashboard › Updates said "the update offered above", but WordPress lists its offers below the panel. It now says "below".
* Fixed: on the network policy screen, the Admin Menu Width help told a Super Admin to drag a slider that screen does not have. The sentence is gone from both screens.
* Fixed: following a link to a setting highlights its row, and the highlight bar sat directly against the setting's label. The label now clears it, and in right-to-left languages the bar and the lock note's rule move to the right-hand side.
* Documentation: the WordPress.org listing showed the settings screen and the patch-status panel under each other's captions. The screenshots are retaken and numbered to match.
* Documentation: the FAQ now says Keel does not manage plugin and theme auto-updates, and explains why subsite administrators on multisite do not see the auto-update column.

= 0.6.5 =
* Fixed: the admin menu width slider stopped previewing the change as you dragged it, on any site that had a width saved. The preview was still there; Keel's own saved rule was overriding it, because that rule is marked important and the preview was not. The preview now outranks it, as it was always meant to.
* Documentation: the FAQ now states a limit that was unstated. Keel reports a setting that is not taking effect by watching WordPress filters. A plugin, theme or host that restyles the admin with CSS registers no filter, so there is nothing to observe - the admin menu width is the usual case, and a managed host styling the admin to its own design is not a conflict Keel can see or should fight.

= 0.6.4 =
* Fixed: the admin menu width slider offered "WordPress default (160px)" as its first stop, but that stop set no width at all - it only made Keel stand down. On a site where a theme, a host, or another plugin had widened the menu, it was the stop you would reach for and the one guaranteed to do nothing. There is now an explicit 160px stop that asserts core's width, and the first stop says what it does: "Leave unchanged".
* Fixed: the conflict notice reported settings shared with callbacks it could not trace and sent you to Site Health, where there were no open issues. The finding was there, but filed under a passing test - green, collapsed, and headed "No attributable policy overlap was found". Untraceable overlaps are now reported as a recommendation, so the notice and Site Health describe the same site.
* Changed: the conflict notice names Keel, drops a sentence the link beneath it already made, and says settings "may be contested" rather than asserting a contest the Site Health test itself declines to assert.

= 0.6.3 =
* Added: the security release on your own version line is now offered on the Updates screen, where WordPress sends you to update. WordPress builds that screen with `get_core_updates()`, which discards every offer flagged for automatic installation — and a same-line security patch is only ever offered that way. So the screen has always listed the newest release and never mentioned the patch. Keel adds it back, directly below the automatic-update settings that decide which release the site would take.
* Fixed: an install started from the Updates screen finished, then sent you to Site Health to find out whether it had worked. Worse, it usually said nothing when you got there: a successful install leaves the site secure, so the panel carrying the result correctly stops rendering. The result now appears on the screen the button was pressed on, once.
* Fixed: the Updates screen offer named the newest release from the WordPress.org stable check, and called it "the update offered above". That check and the update list WordPress renders refresh on their own schedules, so the two could disagree — or the screen could be offering nothing at all. It now reads the same list the screen does, and says nothing rather than inventing an update above.
* Fixed: the Site Health panel told you the Updates screen would not offer the patch, on sites where Keel had just added it there.
* Changed: the ladder markers are one symbol and one label per rung rather than several, and the plainer wording drops an explanation of release numbering nobody reading two version numbers needs.
* Screenshots retaken against the current wording.

= 0.6.2 =
* Fixed: the patch-status panel could promise a scheduled install the ladder directly beneath it contradicted. "Minor updates are permitted and the updater works" does not establish what WordPress would install: a site that also accepts major updates gets the highest release on offer, not the nearest, so the panel could say a patch was scheduled above a ladder marking a different release as the one WordPress would take. The claim is now made only when core's own selection is that patch, and names the release core would take instead when it is not.
* Fixed: the persistent admin notice repeated the same promise with no ladder beneath it to correct it. It renders on every admin screen, so it cannot afford to ask WordPress which release it would install — it now says automatic updating appears available and sends you to Site Health, which can answer.
* Fixed: the panel offered a deliberate install in states where Keel refuses one, and then, once corrected, claimed no install was possible at all. Both were wrong. Keel refuses a blocked install; a deployment workflow or WP-CLI may still manage it, and the wording now says which of those it is speaking for.
* Fixed: an unexpected `null` from WordPress's upgrader was reported as a successful install. Core documents a version string on success, so `null` establishes nothing.
* Added: two live matrix rows that leave the automatic updater operable — one where WordPress would take the same-line patch, one where major updates are permitted and it steps over. Every previous row switched the updater off, so no row had ever rendered the panel in the state these fixes are about.
* Screenshots retaken against a release WordPress.org flags, so the listing images show the current wording.

= 0.6.1 =
* Fixed: `/?author=N` still disclosed the author nicename, and attachment pages still rendered, on sites with those defaults enabled. Both redirects registered on `template_redirect` at the default priority, where core has already registered `redirect_canonical` during load — so they lost the tie on registration order every time. Both now run at priority 9.
* Fixed: a site with comments disabled still answered `/wp/v2/comments/123`. The filter covering every comment listing does not cover the single-item REST route, which reads its row without building a query.
* Fixed: the REST password policy resolved any user ID in the request before the route checked authorization, so the policy ran against another account's login, email and nicename and returned the answer in the validation error. It now resolves only the caller's own user, or one they may edit.
* Fixed: an empty or over-long password reached the breach-screening network call before anything cheap rejected it.
* Added: `tests/hook-precedence.php` and `tests/route-coverage.php`, which check that a registration wins its hook and covers its routes rather than merely existing. The first two fixes above were invisible to the previous suite.
* Thanks to Austin Ginder of Anchor Hosting for the security review these fixes come from.

== Upgrade Notice ==

= 0.10.0 =
Adds Login Answers, on by default: failed logins and password resets get one answer whether or not the account exists. Turn it off under Settings → Site Defaults. With Author Archives off, author pages return a 404. Requires PHP 8.1; older sites stay on 0.9.2. Saved settings carry over.

= 0.9.2 =
Security release. On multisite, the main site's network-wide settings now need a Super Admin. Breach screening no longer stores replies, keeps half its allowance for privileged accounts, and checks the login password as typed. Saved settings carry over.

= 0.9.1 =
Turns off WordPress 7.2's new random post redirects by default, including on sites that update. Adds an opt-in Public Names setting and a Site Health check for email addresses in public names. Setting descriptions are now one sentence, with the details under Help. Saved settings carry over.

= 0.9.0 =
Adds plugin and theme auto-update settings, an Updates policy notice, Site Health update diagnostics and a support report. Admin List Columns becomes Admin List Tables. Existing passwords are re-checked for known breaches at login, at most every 30 days. Saved settings carry over.

= 0.8.0 =
Adds two cached Site Health reports: largest autoloaded options, and cron pressure with core-update delivery evidence. Saved settings and defaults stay unchanged. Reports omit option values, event arguments and failure data, and never delete options, run jobs or change update policy.

= 0.7.0 =
Two new settings are on by default, including on sites that update. Protected Search Results keeps password-protected posts out of searches by people who cannot open them. Broken Shortcodes hides leftover shortcode tags from readers. Stored content is unchanged; turn either off in Site Defaults.

= 0.6.9 =
Fixes symlink-related conflict reports, reduces repeated diagnostic work, and clarifies core-update notices. Internal refactors preserve settings and saved preferences. No new settings; PHP 7.4 remains supported.

= 0.6.8 =
Adds one setting, Environment, and warns when a live site says it is local, which can hold back its email. Also clearer notes for Jetpack sites, a new Site Health check and a block editor that follows the admin menu width.

= 0.6.7 =
Fixes Jetpack: with multicall off (the default), WordPress.com could not manage a connected site. Requests Jetpack verifies as signed now get through. Also clearer Site Health wording and two admin layout fixes. No setting changes.

= 0.6.6 =
Security: with comments off, the REST API no longer serves a comment by ID. Locked settings show what wp-config.php enforces, Site Health notices a new security release the day it ships, and a folded admin menu stays folded. No setting changes.

= 0.6.5 =
The admin menu width slider previews again while you drag it. On any site with a width saved, Keel's own saved rule had been overriding its own preview, so the slider moved nothing on screen. No setting changes.

= 0.6.4 =
Fixes two misleading reports: the menu slider now has a real 160px stop and labels its first stop "Leave unchanged". Conflict notices no longer point to an empty Site Health report. No setting changes.

= 0.6.3 =
The security release on your own version line is now offered on the Updates screen, not only in Site Health — WordPress omits it there, and that is the screen people go to. Installing from it now returns you there and tells you what happened. No setting changes.

= 0.6.2 =
Reporting fixes. The patch-status panel could promise an automatic install that the ladder beneath it contradicted, on sites that also accept major updates. It now agrees with what WordPress would actually install. No setting changes.

= 0.6.1 =
Security fixes. Two protections this plugin documents were not taking effect: the author and attachment redirects lost a priority race against WordPress itself, and disabled comments still answered one REST route. Also tightens the REST password policy. No setting changes.

= 0.6.0 =
Reports whether your WordPress version has publicly known vulnerabilities, names the patched release on your own line rather than the newest, and can install it using WordPress's own upgrader. Asks WordPress.org once a day. No setting changes; nothing installs unless you ask.

= 0.5.10 =
Renames the network screen to Network Policy and corrects links that named a menu which no longer exists. No setting changes and no behaviour changes.

= 0.5.9 =
Removing the plugin now fully clears breach-cache data on sites using Redis or Memcached. Help text rewritten; no setting changes.

= 0.5.8 =
Formatting fix in the Help menu. No behaviour changes.

= 0.5.7 =
Fixes breach-screening status being reported from missing evidence, dependent XML-RPC controls not updating without a reload, and locked sliders accepting edits. Recommended if you use any of those.

= 0.5.6 =
Breach-screening outages are now reported under Site Health rather than passing unnoticed. No change to what is or is not allowed as a password.

= 0.5.5 =
Conflict reports no longer print an internal marker where a plugin name would go, and the dashboard notice now agrees with Site Health about how many settings are affected.

= 0.5.4 =
Warnings about a setting being overridden by another plugin now reach the dashboard rather than only Site Health, and a comments heading no longer appears on posts with comments off.

= 0.5.3 =
Internal change to how Keel's own CSS and JavaScript reach the page; no setting changes and nothing looks different. The Canadian English catalog is no longer bundled — translations now come from translate.wordpress.org like every other locale.

= 0.5.2 =
On WordPress 6.4–6.9 an earlier release could switch the stored AI Connectors value off when you saved any setting. It has no effect before WordPress 7.0, where the control appears under Settings → Keel. To correct it now: `wp option patch update keel_settings disable_ai_connectors yes`

= 0.5.1 =
Policy-overlap diagnostics no longer execute other plugins' callbacks. Re-check prior 0.5.0 conflict results; 0.5.1 reports structural overlap without claiming the configured outcomes disagree.

= 0.5.0 =
Existing sites keep unlimited revision history unless you choose a limit; new activations default to 10. Re-check overlapping-policy results because Keel now reports only confirmed incompatible effects as actionable.

= 0.4.1 =
Fixes the overlapping-settings check naming plugins that were not competing. If 0.4.0 told you another plugin was setting the same things and you have not acted on it yet, re-check under Site Health before deactivating anything. Confirmed results were always correct; the unconfirmed ones are gone.

= 0.4.0 =
From wordpress.org: nothing to do, and your settings are kept. From GitHub before this release: the folder changed from `keel` to `keel-defaults`, so WordPress sees a new plugin rather than an update. Deactivate and delete the old copy — your settings are stored separately and survive it.

= 0.3.0 =
Nothing to do on upgrade: no setting changes meaning and no stored value is rewritten. Multisite networks gain a Network Admin screen that can set any default for every site; it does nothing until a Super Admin uses it.
